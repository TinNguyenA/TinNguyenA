﻿
using System.Diagnostics;
using System.Management.Automation;
using System.Linq;
using System.Text;
using System;
using System.IO;
using System.Collections;
using System.Collections.Generic;
using System.Xml;
using System.Xml.Schema;
using System.Xml.Serialization;

namespace WPF.PSE.Common
{
    public class CommonFunctions
    {
        public static string CreateCodeFromXML(string pathToXML, string pathToXSD)
        {
            string csPath = CallServiceCommandText(pathToXML, pathToXSD);
            string fileCreated = Path.GetFileNameWithoutExtension(csPath).Replace(".", "_") + ".cs";
            string path = Path.GetDirectoryName(csPath);
            try
            {
                if (fileCreated.Contains(" "))
                    Process.Start("notepad.exe", Path.Combine(path, fileCreated));
                else
                    Process.Start("notepad++.exe", Path.Combine(path, fileCreated));
            }
            catch
            {
                Process.Start("notepad.exe", Path.Combine(path, fileCreated));
            }
            return csPath;
        }
        private static string CallServiceCommandText(string pathToXML, string pathToXSD)
        {
            string scriptFile = Path.Combine(Environment.CurrentDirectory, "PsScriptLib", "XSDCODeGen.PS1");
            using (PowerShell PowerShellInstance = PowerShell.Create())
            {
                var sr = new StreamReader(scriptFile);
                PowerShellInstance.AddScript(sr.ReadToEnd());
                if (!Directory.Exists(Path.Combine("C:\\Temp", "CodeGenerate")))
                {
                    CreateFolder(Path.Combine("C:\\Temp", "CodeGenerate"));
                }

                if (string.IsNullOrEmpty(pathToXSD))
                {
                    //CreateXsd file
                    PowerShellInstance.AddParameter("XML_FILE_NAME_DIR", pathToXML);
                    pathToXSD = Path.Combine("C:\\Temp", "CodeGenerate", Path.GetFileNameWithoutExtension(pathToXML)) + ".xsd";
                    PowerShellInstance.AddParameter("XSD_FILE_NAME_DIR", pathToXSD);
                }
                else
                {
                    //CreateXml file
                    CreateSampleXML(pathToXSD, Path.Combine("C:\\Temp", "CodeGenerate", Path.GetFileNameWithoutExtension(pathToXSD)) + ".xml");
                    PowerShellInstance.AddParameter("XSD_FILE_NAME_DIR", pathToXSD);
                    pathToXSD = Path.Combine("C:\\Temp", "CodeGenerate", Path.GetFileNameWithoutExtension(pathToXSD)) + ".cs";
                }
                PowerShellInstance.Invoke();
                //var s = PowerShellInstance.Streams.Progress.Count;                
                foreach (var error in PowerShellInstance.Streams.Error)
                {
                    Debug.WriteLine("=>" + error.ErrorDetails);
                }

                return pathToXSD;
            }
        }
        private static void CreateSampleXML(string xsdLocation, string saveto)
        {

            using (var stream = new MemoryStream(File.ReadAllBytes(xsdLocation)))
            {
                var schema = XmlSchema.Read(XmlReader.Create(stream), null);
                var gen = new Microsoft.Xml.XMLGen.XmlSampleGenerator(schema, new XmlQualifiedName("rootElement"));
                gen.WriteXml(XmlWriter.Create(saveto));
            }
        }

        private static void CreateFolder(string saveto)
        {
            Directory.CreateDirectory(saveto);
        }

        public static int DoFileReplaceOnly(string RootDirectoryName, string dest, string extType, ref string strMsg, int count =0)
        {
            var typeOfFile = extType;
            typeOfFile = typeOfFile.ToLower();
            string[] listOfExt = typeOfFile.Split(".".ToCharArray(), StringSplitOptions.RemoveEmptyEntries);
            if (listOfExt.Length == 0)
                listOfExt = new string[] { "*" };

            List<FileInfo> filesSource = CollectAllSourceFiles(RootDirectoryName, listOfExt);
            List<FileInfo> filesDest = CollectAllSourceFiles(dest, listOfExt);
           
            foreach (FileInfo sourceF in filesSource)
            {
                foreach (FileInfo destF in filesDest)
                    if(destF.Name + destF.Extension == sourceF.Name + sourceF.Extension)
                    {
                        // replace
                        FileAttributes at = File.GetAttributes(destF.FullName);
                        if (at.ToString().Contains(FileAttributes.ReadOnly.ToString()))
                        {
                            File.SetAttributes(destF.FullName, FileAttributes.Normal);
                        }
                        count++;
                        strMsg += $"Replace From {sourceF.FullName} to {destF.FullName}\r\n";
                        sourceF.CopyTo(destF.FullName, true);
                    }
            }
            return count;
        }

        private static List<FileInfo> CollectAllSourceFiles(string rootDirectoryName, string[] listOfExt)
        {
            List<FileInfo> files = new List<FileInfo>();
            DirectoryInfo dif = new DirectoryInfo(rootDirectoryName);
            foreach (string extType in listOfExt)
            {
                if (string.IsNullOrWhiteSpace(extType))
                    continue;
                string strWideCard = "*." + extType;
                foreach (FileInfo fsi in dif.GetFiles(strWideCard))
                {
                    files.Add(fsi);                    
                }
                
                foreach (DirectoryInfo lcDif in dif.GetDirectories())
                {
                    List<FileInfo> file2 = CollectAllSourceFiles(lcDif.FullName, listOfExt);
                    files.AddRange(file2);
                }
            }
            return files;
        }

        public static void OpenFileEditor(string pathFileName)
        {
            //if (string.IsNullOrEmpty(pathFileName))
            //{
            //    Process.Start("devenv.exe", pathFileName);
            //    return;
            //}            
            try
            {
                if (pathFileName.Contains(" "))
                    Process.Start("notepad.exe", pathFileName);
                else
                    Process.Start("notepad++.exe", pathFileName);
            }
            catch
            {
                Process.Start("notepad.exe", pathFileName);
            }
        }
        public static T ConvertXMLToClassObject<T>(Stream filePath) where T : class
        {
            XmlSerializer serializer = new XmlSerializer(typeof(T));
            T classObject = (T)serializer.Deserialize(filePath);
            return classObject;
        }

        public static T ConvertXMLToClassObject<T>(string xmlString) where T : class
        {
            if (xmlString == null)
                return null;
            StringReader stringReader = new StringReader(xmlString);
            XmlSerializer serializer = new XmlSerializer(typeof(T));
            T classObject = (T)serializer.Deserialize(stringReader);
            return classObject;
        }

        public static void ConvertClassObjectToXML<T>(Stream obj, T data) where T : class
        {
            if (data == null)
                return;
            StringWriter stringWriter = new StringWriter();
            XmlSerializer serializer = new XmlSerializer(typeof(T));
            serializer.Serialize(obj, data);
        }
        public static string ConvertClassObjectToXmlString(object theObj)
        {
            var result = "";
            try
            {
                var serializer = new XmlSerializer(theObj.GetType());
                using (var textWriter = new StringWriter())
                {
                    serializer.Serialize(textWriter, theObj);
                    result = textWriter.ToString();
                }
            }
            catch (Exception ex)
            {
                //($"Serialization was unsuccessful: {ex.Message}");
            }

            return result;
        }
        public static int GetCopyFileList(bool? includeSub,
                                          bool IsCPToOneDirectory,
                                          ref string strMsg,
                                          string extType,
                                          string extExcludedType,
                                          bool OverwriteReadONLY,
                                          DirectoryInfo dif,
                                          int count,
                                          string source,
                                          string dest,
                                          string RootDirectoryName = "")
        {
            if (IsCPToOneDirectory)
                RootDirectoryName = dest;
            
                var typeOfFile = extType;
                typeOfFile = typeOfFile.ToLower();
                string[] listOfExt = typeOfFile.Split(".".ToCharArray(), StringSplitOptions.RemoveEmptyEntries);
                if (listOfExt.Length == 0)
                    listOfExt = new string[] { "*" };
            foreach (string s in listOfExt)
            {
                if (string.IsNullOrWhiteSpace(s))
                    continue;
                string strWideCard = "*." + s;
                foreach (FileInfo fsi in dif.GetFiles(strWideCard))
                {
                    bool isOriginalRO = false;

                    DirectoryInfo di = new DirectoryInfo(fsi.DirectoryName.Replace(source, dest));
                    if (IsCPToOneDirectory)
                        di = new DirectoryInfo(RootDirectoryName);

                    if (isInExcludedFileList(fsi, extExcludedType))
                        continue;
                    else
                    {
                        //over write decision

                        if (!IsCPToOneDirectory && File.Exists(fsi.FullName.Replace(source, dest)))
                        {
                            FileAttributes at = File.GetAttributes(fsi.FullName.Replace(source, dest));
                            if (fsi.LastWriteTime.CompareTo(
                             File.GetLastWriteTime(fsi.FullName.Replace(source, dest))) <= 0)
                                continue;
                            if (at.ToString().Contains(FileAttributes.ReadOnly.ToString()))
                            {
                                isOriginalRO = true;
                                File.SetAttributes(fsi.FullName.Replace(source,
                                    dest), FileAttributes.Normal);
                            }
                        }
                        else if (IsCPToOneDirectory && File.Exists(RootDirectoryName + "//" + fsi.Name))
                        {
                            FileAttributes at = File.GetAttributes(RootDirectoryName + "//" + fsi.Name);
                            if (fsi.LastWriteTime.CompareTo(
                             File.GetLastWriteTime(RootDirectoryName + "//" + fsi.Name)) < 0)
                                continue;
                            if (at.ToString().Contains(FileAttributes.ReadOnly.ToString()))
                            {
                                isOriginalRO = true;
                                File.SetAttributes(RootDirectoryName + "//" + fsi.Name, FileAttributes.Normal);
                            }
                        }
                        if (!di.Exists && !IsCPToOneDirectory)
                            di.Create();

                        if (IsCPToOneDirectory)
                        {
                            DirectoryInfo newDest = new DirectoryInfo(RootDirectoryName);
                            if(!newDest.Exists)
                                newDest.Create();
                            fsi.CopyTo(RootDirectoryName + "//" + fsi.Name, true);
                        }
                        else
                            fsi.CopyTo(fsi.FullName.Replace(source, dest), true);


                        if (isOriginalRO && OverwriteReadONLY)
                        {
                            if (IsCPToOneDirectory)
                            {
                                File.SetAttributes(RootDirectoryName + "//" + fsi.Name, FileAttributes.ReadOnly);
                            }
                            else
                            {
                                File.SetAttributes(fsi.FullName.Replace(source, dest), FileAttributes.ReadOnly);
                            }
                        }

                        else
                        {
                            if (IsCPToOneDirectory)
                            {
                                File.SetAttributes(RootDirectoryName + "//" + fsi.Name, FileAttributes.Normal);
                            }
                            else
                            {
                                File.SetAttributes(fsi.FullName.Replace(source, dest), FileAttributes.Normal);
                            }
                        }
                        strMsg += fsi.FullName + "\r";
                        count++;
                    }
                }


                if (includeSub == false)
                    return count;

                foreach (DirectoryInfo lcDif in dif.GetDirectories())
                {
                    if (IsCPToOneDirectory)
                    {
                        count += GetCopyFileList(true, IsCPToOneDirectory, ref strMsg, extType, extExcludedType,
                         OverwriteReadONLY, lcDif, 0, lcDif.FullName, RootDirectoryName);
                    }
                    else
                    {
                        count += GetCopyFileList(true, IsCPToOneDirectory, ref strMsg, extType, extExcludedType,
                         OverwriteReadONLY, lcDif, 0, lcDif.FullName, dest + "\\" + lcDif.Name);
                    }
                }
            }
            return count;
        }

        private static bool isInExcludedFileList(FileInfo fsi, string extExcludedType)
        {
            string typeOfFile = extExcludedType;
            if (string.IsNullOrEmpty(typeOfFile))
                return false;
            else
                typeOfFile = typeOfFile.ToLower();
            string CompareTo = fsi.Extension.TrimStart('.').ToLower();
            string[] listOfExt = typeOfFile.Split('.');
            foreach (string s in listOfExt)
            {
                if (s.Trim().Equals(CompareTo))
                    return true;
            }
            return false;
        }


    }

}
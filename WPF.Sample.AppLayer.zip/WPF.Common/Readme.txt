﻿WPF.Common
------------------------------------------
Add resource dictionaries, common user controls, converters and other WPF-Specific items in this project.

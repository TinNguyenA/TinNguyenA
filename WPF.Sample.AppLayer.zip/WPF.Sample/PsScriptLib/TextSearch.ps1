param (
    [string]$path  = "",
    [string]$ext = "",
    [string]$txt = "",
    [string]$case_Ss=""
 )
 $SearchLocation  =$path
 $FileExt = $ext
 $pattern = $txt
 
  $SearchLocation = $SearchLocation + "\\" + $FileExt

   Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass -Force -ErrorAction SilentlyContinue
try{
    if($txt -eq "")
    {
     'Missing input param value -txt.' + "`r`n `r`n" + ' Please use this format ==> .\TextSearch.ps1 -path "C:\Proj" -ext "*.cs" -txt "ProcRpts" ' + "`r`n"
    }
    if($path -eq "")
    {
     throw 'Missing input param value -path.' + "`r`n `r`n" + ' Please use this format ==> .\TextSearch.ps1 -path "C:\Proj" -ext "*.cs" -txt "ProcRpts" ' + "`r`n" 
    }
    if($ext -eq "")
    {
     throw 'Missing input param value -ext.' + "`r`n `r`n" + 'Please use this format ==> .\TextSearch.ps1 -path "C:\Proj" -ext "*.cs" -txt "ProcRpts"' + "`r`n"
    }
    else{
   # cls
    #Get-ChildItem -Recurse  -Path  $SearchLocation | Select-String -Pattern $pattern | out-GridView
     if($case_Ss -eq "Yes"){
      Get-ChildItem -Recurse  -Path  $SearchLocation | Select-String -Pattern $pattern -CaseSensitive
      }
      else{
        Get-ChildItem -Recurse  -Path  $SearchLocation | Select-String -Pattern $pattern 
      }
    #Get-ChildItem -Recurse  -Path  $SearchLocation | Select-String -Pattern $pattern -CaseSensitive | Format-List -Property LineNumber, Line, Pattern, Filename, Path
    }
}
catch [System.Net.WebException],[System.Exception]
{
     Write-Output "Ran into an issue: $($PSItem.ToString())"
      $_ | Out-GridView
}
finally
{
# Write-Host "Search Ended";
}
<#
example:
 set-location "C:\Install\Powershell Tools"
 .\TextSearch.ps1 -path "C:\Proj\R\CODIS\CODIS_11.0" -ext "*.cs" -txt "Utils.*aitForMessageInserted"

Ref:
 display option:           https://docs.microsoft.com/en-us/powershell/scripting/samples/using-format-commands-to-change-output-view?view=powershell-7.1
 search patern option Doc: https://docs.microsoft.com/en-us/powershell/scripting/developer/cmdlet/supporting-wildcard-characters-in-cmdlet-parameters?view=powershell-7.1
#>
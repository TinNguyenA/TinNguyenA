param (
    [string]$ScriptLocation  = "\Trunk\Scripts\Builds\TeamCityBuilds",
    [string]$ServerInstance = "localhost",
    [string]$DatabaseSource = "CODIS",
    [string]$sql ,
	[string]$Command = "Get",
    [string]$LocalRepo      = "C:\Proj\R\CODIS"
 )
 Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass -Force -ErrorAction SilentlyContinue
 #cls
  $sql = "Use CODIS; " + $sql
 
  $ScriptLocation = $LocalRepo + $ScriptLocation
 . $($ScriptLocation + $("\Common.ps1"))

Set-Location $ScriptLocation
try{
if($Command -eq "Get")
{
	Invoke-Sqlcmd -Query $sql -ServerInstance $ServerInstance 
}
elseif ($Command -eq "short cut")
{
    Invoke-Sqlcmd -Query $sql -ServerInstance $ServerInstance | out-GridView
}
 else
{
    Invoke-Sqlcmd -Query $sql -ServerInstance $ServerInstance 
	Invoke-Sqlcmd -Query $sql -ServerInstance $ServerInstance | out-GridView
}
}
catch
{
     #Write-Host "Caught the exception";
	Invoke-Sqlcmd -Query $("Select 'Error Compare the XML column' Error,'"+  $sql +"' as info") -ServerInstance $ServerInstance | out-GridView
}
param (
	[string]$defaultDatabaseRootPath= "C:\Program Files\Microsoft SQL Server\MSSQL15.MSSQLSERVER\MSSQL\DATA\",
    [string]$ServerInstance = ".",
    [string]$DatabaseSource = "CODIS",
    [string]$DatabaseBackup = "CODIS_Bak",
	[string]$LocalRepo      = "C:\Proj\R\CODIS"
 )
# Install-Module -Name SqlServer -Scope AllUsers 
 Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass -Force 
 cls
 $BakLocation = $LocalRepo +"\"+ $DatabaseBackup+".bak"
 push-location
import-module sqlps -disablenamechecking
pop-location

if(Test-Path -path $BakLocation  )
  {  
   Remove-Item -Path $BakLocation -Force 
  }
 
 invoke-sqlcmd -ServerInstance "."   -Query "Drop database $DatabaseBackup;"

Backup-SqlDatabase -ServerInstance  $ServerInstance -Database $DatabaseSource -BackupFile $BakLocation 
 
#restore option 1 (not work for application)
 try{
  #get the sqlserver version 
 
	$sqlServerSnapinVersion = (Get-Command Restore-SqlDatabase).ImplementingType.Assembly.GetName().Version.ToString()
	$assemblySqlServerSmoExtendedFullName = "Microsoft.SqlServer.SmoExtended, Version=$sqlServerSnapinVersion, Culture=neutral, PublicKeyToken=89845dcd8080cc91"

	$mdf = New-Object "Microsoft.SqlServer.Management.Smo.RelocateFile, $assemblySqlServerSmoExtendedFullName"('CODIS', $("$defaultDatabaseRootPath$DatabaseBackup"+".mdf"))
	$ldf = New-Object "Microsoft.SqlServer.Management.Smo.RelocateFile, $assemblySqlServerSmoExtendedFullName"('CODIS_Log', $("$defaultDatabaseRootPath$DatabaseBackup" + "_log.ldf"))
	restore-sqldatabase -serverinstance $ServerInstance -database $DatabaseBackup -backupfile $BakLocation  -RelocateFile @($mdf,$ldf) 

}
 catch
{
 $_ | Out-GridView
# Write-Error -Message  "bad" -ErrorAction Stop
}

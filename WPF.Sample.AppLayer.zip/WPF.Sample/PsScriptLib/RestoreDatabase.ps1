param (
	[string]$defaultDatabaseRootPath= "C:\Program Files\Microsoft SQL Server\MSSQL15.MSSQLSERVER\MSSQL\DATA\",
    [string]$ServerInstance = ".",
    [string]$dbname = "CODIS",
	[string]$LocalRepo  = "C:\Proj\R\CODIS"
 )
  # Attach reference: common utility in local 
  $executeDir = $myInvocation.MyCommand.Definition
	Write-Host $executeDir
    $DestDir =  [System.IO.Path]::GetDirectoryName($executeDir)

 . $($DestDir + $("\Common.ps1"))
# Install-Module -Name SqlServer -Scope AllUsers 
     Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass -Force 
     cls
  [System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SqlServer.SMO") | out-null
	$sqlServer =  New-Object Microsoft.SqlServer.Management.Smo.Server $env:COMPUTERNAME	
	try
		{
			#$sqlServer.KillAllProcesses($dbname)
			$sqlServer.KillDatabase($dbname)
		}
	catch
	{
         $_ | Out-GridView
	  # exit -1
	}
     $BakLocation = $LocalRepo +"\"+ $dbname+"_Bak.bak"
     push-location
    import-module sqlps -disablenamechecking
    pop-location
  try{
    restore-sqldatabase -serverinstance $ServerInstance -database $dbname -backupfile $BakLocation 
}
 catch
{
 $_ | Out-GridView
}

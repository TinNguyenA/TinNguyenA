param (
    [string]$SearchLocation  = "\Trunk",
    [string]$FileExt = "***",
    [string]$pattern = "###",
    [string]$LocalRepo  = "C:\Proj\R\CODIS"
 )
  $SearchLocation = $LocalRepo + $SearchLocation + $FileExt
   Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass -Force -ErrorAction SilentlyContinue
try{

    Get-ChildItem -Recurse  -Path  $SearchLocation| Select-String -Pattern $pattern -CaseSensitive | out-GridView
}
catch
{
     $_ | Out-GridView
}
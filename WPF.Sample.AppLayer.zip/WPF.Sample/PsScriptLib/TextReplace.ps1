param (
    [string]$path  = "C:\Proj\R\CODIS\CODIS_9.0",
    [string]$ext = "*.csproj",
    [string]$txtOld = "Version=13.0.2000.0",
    [string]$txtNew = "Version=13.0.4000.0"
 )
 $SearchLocation  =$path
 $FileExt = $ext
 $pattern = $txt
 
  $SearchLocation = $SearchLocation + "\\" + $FileExt

   Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass -Force -ErrorAction SilentlyContinue
try{
  set-location $path
   $configFiles = Get-ChildItem . $ext -rec
foreach ($file in $configFiles)
{
 #Write-Output "File: $($file.ToString())"
   (Get-Content $file.PSPath) |
    Foreach-Object { $_ -replace $txtOld, $txtNew } |
   Set-Content $file.PSPath
}}
catch [System.Net.WebException],[System.Exception]
{
     Write-Output "Ran into an issue: $($PSItem.ToString())"
      $_ | Out-GridView
}
finally
{
# Write-Host "Search Ended";
}
<#
example:
 set-location "C:\Install\Powershell Tools"
 .\TextReplace.ps1 -path "C:\Proj\R\CODIS\CODIS_9.0" -ext "*.csproj" -txtOld "Version=13.0.2000.0" -txtNew "Version=13.0.4000.0"
 set-location "C:\Install\Powershell Tools"
 .\TextReplace.ps1 -path "C:\Proj\R\CODIS\CODIS_9.0" -ext "*.vbproj" -txtOld "Version=13.0.2000.0" -txtNew "Version=13.0.4000.0"

Ref:
 display option:           https://docs.microsoft.com/en-us/powershell/scripting/samples/using-format-commands-to-change-output-view?view=powershell-7.1
 search patern option Doc: https://docs.microsoft.com/en-us/powershell/scripting/developer/cmdlet/supporting-wildcard-characters-in-cmdlet-parameters?view=powershell-7.1
#>
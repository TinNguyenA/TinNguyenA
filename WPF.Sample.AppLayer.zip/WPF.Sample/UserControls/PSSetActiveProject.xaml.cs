﻿using System.IO;
using System.Windows;
using System.Windows.Controls;
using WPF.PSE.ViewModelLayer;
using System;
using System.Collections;
using System.Linq;
using System.Runtime.InteropServices;
using System.Diagnostics;
using System.Security.Principal;
using WPF.PSE.AppLayer.DataObject;
using WPF.PSE.AppLayer.Models;
using Common.PSELibrary.Tool;
using System.Collections.Specialized;
using System.Threading;
using System.Text;
using System.Collections.ObjectModel;
using System.Management.Automation;
using System.Reflection;
using Microsoft.Win32.SafeHandles;
using System.ComponentModel;
using Common.PSELibrary;
using ServiceBase = System.ServiceProcess.ServiceBase;

namespace WPF.PSE.Utility.UserControls
{
    public partial class PSSetActiveProject : UserControl, IPSUserControl
    {
        private static PowerShell _ps;
        [DllImport("kernel32.dll")]
        static extern bool CreateSymbolicLink(string source,
                                              string target,
                                              SymbolicLink linkType);
        enum SymbolicLink
        {
            File = 0,
            Directory = 1
        }
        private SQLTrackingViewModel _viewModel = null;
        private UserControl _tabUserControl = null;
        private CODISUtilGenericData _utilsData = null;
        private string _Localrepo;// = Environment.GetEnvironmentVariable("localrepo");
        private string _MV;// Environment.GetEnvironmentVariable("MV");

        public PSSetActiveProject(IDictionary cookie)
        {
            InitializeComponent();            
            

            // Connect to instance of the view model created by the XAML
            _viewModel = (SQLTrackingViewModel)this.Resources["viewModel"];
            _utilsData = _viewModel.UtilData;
            _viewModel.PopupFlyMessage("Source safe mapping location", MessageBoxType.Image,"tfsBinding", 12);
            HandleEvironmentException();
            _viewModel.DisplayStatusMessage("Wecome to CODIS");
            btnReload_Click(null, null);        
        }

        private void HandleEvironmentException()
        {
            if (_utilsData.Items.Any(x => x.Key == "Environment Variables" && x.Name=="MV"))
                _MV = _utilsData.Items.Where(x => x.Key == "Environment Variables" && x.Name == "MV").First().Value;

            if (_utilsData.Items.Any(x => x.Key == "Environment Variables" && x.Name == "LocalRepo"))
                _Localrepo = _utilsData.Items.Where(x => x.Key == "Environment Variables" && x.Name == "LocalRepo").First().Value;
        }

        private void btnReload_Click(object sender, RoutedEventArgs e)
        {            
            btnInstalDB.IsEnabled = false;
            //int lastSelectedIndex = 0;
            //if (sender != null)
            //{
            //lastSelectedIndex = DBCommonScript.SelectedIndex;
            TextVSVersion.Items.Clear();
            DBCommonScript.Items.Clear();
            //}
            //else
            //{
            _utilsData = new UtilDataContext().LoadUtilityData<CODISUtilGenericData>();
            //}
            cbxConfigKeys.Items.Clear();
            LoadConfigDropDownList();
            txtConfigKey.Text = "";
            txtConfigName.Text = "";
            txtConfigValue.Text = "";
            LoadVSPathData();            
            LoadFavoriteScript();
            LoadBranchVersionSupported();
            LoadCODISDbType();
            LoadCREPathData();
            //if (DBCommonScript.Items.Count - 1 >= lastSelectedIndex)
                DBCommonScript.SelectedIndex = -1;
            TextProjectPathSelected.SelectedIndex = -1;
            TextVSVersion.SelectedIndex = -1;
            TextCodisVersion.SelectedIndex = -1;
            TextDBType.SelectedIndex = -1;

            LoadVSPathLastUsedVesion();
        }

        private void LoadCODISDbType()
        {
            TextDBType.Items.Clear();
            foreach (UtilityGenericData data in _utilsData.Items.Where(x => x.Key == "CODISDBType").OrderBy(y => y.Name))
            {
                TextDBType.Items.Add(data);
            }
            if (TextDBType.Items.Count == 1)
                TextDBType.SelectedIndex = 0;
        }

        private void LoadBranchVersionSupported()
        {
            txtBranchName.Items.Clear();
            foreach (UtilityGenericData data in _utilsData.Items.Where(x => x.Key == "CODISVersion").OrderBy(y => y.Name))
            {
                txtBranchName.Items.Add(data);
            }

            txtBranchName.SelectedIndex = -1;
        }
        private void LoadFavoriteScript()
        {
            foreach (UtilityGenericData data in _utilsData.Items.Where(x => x.Key == "FrequentlyUseSQL").OrderBy(y => y.Name))
            {
                DBCommonScript.Items.Add(data);
            }
        }

        private void LoadVSPathData()
        {
            var allVsVersion = _utilsData.Items.Where(x => x.Key == "VSLocation").OrderBy(y => y.Name);
            foreach (UtilityGenericData data in allVsVersion)
            {
                TextVSVersion.Items.Add(data);
            }
            if (allVsVersion.Count() > 0)
                TextVSVersion.SelectedIndex = allVsVersion.Count() - 1;
        }
        private void LoadCREPathData()
        {
            var allVsVersion = _utilsData.Items.Where(x => x.Key == "CREPath").OrderBy(y => y.Name);
            foreach (UtilityGenericData data in allVsVersion)
            {
                RapidPathSelected.Items.Add(data);
            }
            if (allVsVersion.Count() > 0)
                RapidPathSelected.SelectedIndex = allVsVersion.Count() - 1;
        }

        private void LoadConfigDropDownList()
        {
            if (cbxConfigKeys.Items.Count < 1)
                foreach (UtilityGenericData data in _utilsData.Items.OrderBy(y => y.CombinedKey))
                {
                    cbxConfigKeys.Items.Add(data);
                }
        }

        public double MWidth
        {
            get { return this.Width; }
            set { this.Width = value; }
        }
        public double MHeight
        {
            get { return this.Height; }
            set { this.Height = value + 120; }
        }
        public double TabWidth
        {
            get { return this.Width; }
            set
            {
                //this.Width = value;
            }
        }
        public double TabHeight
        {
            get { return ((TabPageControl)_tabUserControl).Height; }
            set
            {
                this.Height = value + 120;
            }
        }

        public string GetSelectedProject
        {
            get
            {
                if (((UtilityGenericData)txtBranchName.SelectedValue)?.Value != "")
                    return ((UtilityGenericData)txtBranchName.SelectedItem)?.Name;
                else
                {
                    return null;
                }
            }
        }
        public string PSEnvironment { get; set; }
        public string TxtEditor { get; private set; }

        private void CreateDirLink_Click(object sender, RoutedEventArgs e)
        {
            this.Cursor = System.Windows.Input.Cursors.Wait;
            try
            {
                string symbolicLinkD = Path.Combine(_Localrepo, "Trunk", "Source", "Product", "Debug");
                string symbolicLinkR = Path.Combine(_Localrepo, "Trunk", "Source", "Product", "Release");
                string symbolicLinkD_BackUp = Path.Combine(_Localrepo, "Trunk", "Source", "Product", "Debug_Bak");
                string symbolicLinkR_BackUp = Path.Combine(_Localrepo, "Trunk", "Source", "Product", "Release_Bak");
                StopAllTheAppServices(sender);
                
                string workingDebugFolder = Path.Combine(_Localrepo, txtBranchName.SelectedItem.ToString(), "Source", "Product", "Debug");
                string workingReleaseFolder = Path.Combine(_Localrepo, txtBranchName.SelectedItem.ToString(), "Source", "Product", "Release");

                DirectoryInfo di = new DirectoryInfo(workingDebugFolder);
                if (txtBranchName.SelectedItem.ToString() == "Trunk" && di.Attributes.HasFlag(FileAttributes.ReparsePoint))
                {                    
                    HandleTrunkRetoreDir(symbolicLinkD, symbolicLinkD_BackUp);
                    HandleTrunkRetoreDir(symbolicLinkR, symbolicLinkR_BackUp);
                }
                else if(di.Attributes.HasFlag(FileAttributes.ReparsePoint) || txtBranchName.SelectedItem.ToString() != "Trunk")
                {
                    HandleTrunkBackupDir(symbolicLinkD, symbolicLinkD_BackUp);
                    HandleTrunkBackupDir(symbolicLinkR, symbolicLinkR_BackUp);
                }

                if (!Directory.Exists(workingDebugFolder) || !Directory.Exists(workingReleaseFolder))
                {                  
                    Directory.CreateDirectory(workingDebugFolder);                   
                    _viewModel.PopupFlyMessage($"Environment is not ready until you compile {txtBranchName.Text}.",
                                           MessageBoxType.Information);
                    Directory.CreateDirectory(workingReleaseFolder);
                }
                bool status = CreateSymbolicLink(symbolicLinkD, workingDebugFolder, SymbolicLink.Directory);
                status = CreateSymbolicLink(symbolicLinkR, workingReleaseFolder, SymbolicLink.Directory);
                LoadVSPathLastUsedVesion();
                _viewModel.DisplayStatusMessage($"{txtBranchName.SelectedItem.ToString()} Is now ready.");

                // Set up the registry NOT Working
                //try
                //{
                //    if (RunasAdmin())
                //    {
                //        Process.Start("regedit.exe");
                //        ProcessStartInfo info = new ProcessStartInfo("regedit.exe",  $"{Path.Combine(_MV, "UtilityData", "CODISTrunk_V12.reg")}");
                //        info.UseShellExecute = true;
                //        info.WorkingDirectory = $"{Path.Combine(_MV, "UtilityData")}";
                //        info.CreateNoWindow = true;
                //        info.Verb = "runas";
                //        Process.Start(info);
                //    }
                //    else
                //    {
                //        MessageBox.Show("You are not running as Administrator", "Notice", MessageBoxButton.OK, MessageBoxImage.Warning);
                //        Process.Start($"{Path.Combine(_MV, "UtilityData", "CODISTrunk_V12.reg")}");
                //    }
                //}
                //catch
                //{
                //    _viewModel.DisplayStatusMessage($"Not able to open the reg");
                //    return;
                //}
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message + "\r\nPlease close File Explorer that may be opening CODIS debug folders.", "Setup Env Error", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }
            finally
            {
                this.Cursor = System.Windows.Input.Cursors.Arrow;
            }
        }

        private void HandleTrunkRetoreDir(string restoreDest, string restoreSource)
        {
            DirectoryInfo di = new DirectoryInfo(restoreDest);
            di.Delete(true);
            di = new DirectoryInfo(restoreSource);
            if (di.Exists)
            {
                di.MoveTo(restoreDest);
            }       
        }

        private static void HandleTrunkBackupDir(string trunkSource, string backUpSource)
        {
            DirectoryInfo diTarget = new DirectoryInfo(trunkSource);
            if (diTarget.Exists && diTarget.Attributes.HasFlag(FileAttributes.ReparsePoint))
            {
                diTarget.Delete(true);
                return;
            }
            if(!diTarget.Exists)
                return; // nothing to backup            
            DirectoryInfo diDesc = new DirectoryInfo(backUpSource);            
            if (diDesc.Exists)
            {
                diDesc.Delete(true);
            }
            diTarget.MoveTo(backUpSource);
        }

        private void CloseIISExpress()
        {
            var p = Process.GetProcessesByName("iisexpress", ".");
            if (p != null)
            {
                var iisCount = p.Count();
                while (iisCount > 0)
                {
                    iisCount--;
                    p[iisCount].Kill();
                    p[iisCount].Close();
                    p[iisCount].Dispose();
                }
            }
        }

       
       

        private void Process_GridDataAdded(Collection<PSObject> data)
        {
            string symbolicLinkD = Path.Combine(_Localrepo, "Trunk", "Source", "Product", "Debug");
            DirectoryInfo di = new DirectoryInfo(symbolicLinkD);
            if(!di.Exists)
            {
                di.Create();
                symbolicLinkD = "Not Compiled before.";
            }
            else if (!di.Attributes.HasFlag(FileAttributes.ReparsePoint))
            {
                symbolicLinkD = "Trunk";
            }
            else
            {
                string path = GetRealPath(di.FullName).Replace("\\Source\\Product\\Debug", "");
                if(path == "-1")
                {
                    symbolicLinkD = "Not found.";
                }
                else
                    symbolicLinkD = path.Split('\\').Last();
            }

                TxtLastAccessEnvironment.Text = "Working code: " + symbolicLinkD+" -- " +
                ((System.Data.DataRow)data[0].BaseObject).ItemArray[0].ToString();
            if (txtBranchName.Text != symbolicLinkD && symbolicLinkD != "Not Compiled before." && symbolicLinkD != "Not found.")
                txtBranchName.Text = symbolicLinkD;
        }
        private void LoadVSPathLastUsedVesion()
        {
            Utils.RunSQL(@"SELECT 'Database: ' + CODIS_Domain.Domain_Level + ' '+ Lab.Lab_ID + ' '+ CODIS_Version.Version FROM  CODIS_Domain
                       INNER JOIN
                       Lab ON CODIS_Domain.State_CD = Lab.State_CD AND CODIS_Domain.Lab_CD = Lab.Lab_CD
                       CROSS JOIN
                       (select top 1 * from CODIS_Version order by Version_CD desc) CODIS_Version",
                    MainWindow.GetLocalRepo(), Process_GridDataAdded, false);
        }
        [DllImport("kernel32.dll", EntryPoint = "CreateFileW", CharSet = CharSet.Unicode, SetLastError = true)]
        private static extern SafeFileHandle CreateFile(string lpFileName, int dwDesiredAccess, int dwShareMode, IntPtr securityAttributes, int dwCreationDisposition, int dwFlagsAndAttributes, IntPtr hTemplateFile);

        [DllImport("kernel32.dll", EntryPoint = "GetFinalPathNameByHandleW", CharSet = CharSet.Unicode, SetLastError = true)]
        private static extern int GetFinalPathNameByHandle([In] SafeFileHandle hFile, [Out] StringBuilder lpszFilePath, [In] int cchFilePath, [In] int dwFlags);
        private const int CREATION_DISPOSITION_OPEN_EXISTING = 3;
        private const int FILE_FLAG_BACKUP_SEMANTICS = 0x02000000;
        public static string GetRealPath(string path)
        {
            if (!Directory.Exists(path) && !File.Exists(path))
            {
                MessageBoxResult  option = MessageBox.Show($"Please check the path is not found:\r\n.{path}", "Error", MessageBoxButton.OK);  
                return "-1";
            }

            SafeFileHandle directoryHandle = CreateFile(path, 0, 2, IntPtr.Zero, CREATION_DISPOSITION_OPEN_EXISTING, FILE_FLAG_BACKUP_SEMANTICS, IntPtr.Zero); //Handle file / folder

            if (directoryHandle.IsInvalid)
            {
                // throw new Win32Exception(Marshal.GetLastWin32Error());
                Directory.Delete(path);
                Directory.CreateDirectory(path);
            }

            StringBuilder result = new StringBuilder(512);
            int mResult = GetFinalPathNameByHandle(directoryHandle, result, result.Capacity, 0);

            if (mResult < 0)
            {
                throw new Win32Exception(Marshal.GetLastWin32Error());
            }

            if (result.Length >= 4 && result[0] == '\\' && result[1] == '\\' && result[2] == '?' && result[3] == '\\')
            {
                return result.ToString().Substring(4); // "\\?\" remove
            }
            return result.ToString();
        }
        
        private void EnablePathCheck(object sender, SelectionChangedEventArgs e)
        {
            if (TextProjectPathSelected == null || GetSelectedProject == null)
                return;
            btnUpdateReg.IsEnabled = true;
            TextProjectPathSelected.IsEnabled = true;
            TextProjectPathSelected.Items.Clear();
            string thePath = Path.Combine(_Localrepo, GetSelectedProject, "Source", "Product");
            TextProjectPathSelected.Items.Add(thePath);
            TextProjectPathSelected.SelectedIndex = 0;
            TextProjectPathSelected.ToolTip = $"%Localrepo%/{GetSelectedProject}/Source/Product/CODIS.sln";
            if (TextVSVersion != null && TextVSVersion.Items.Count > 0)
                TextVSVersion.SelectedIndex = TextVSVersion.Items.Count - 1;
            if (TextCodisVersion.Text.Length > 0)
                btnInstalDB.IsEnabled = true;
        }

        private void EnableScriptChange(object sender, SelectionChangedEventArgs e)
        {
            btnInstalDB.IsEnabled = txtBranchName.SelectedIndex > 0 && TextCodisVersion.SelectedIndex > -1 && TextDBType.SelectedIndex > -1;
            if (TextVSVersion.SelectedItem != null)
            {
                TextVSVersion.ToolTip = ((UtilityGenericData)TextVSVersion.SelectedItem)?.Value;
            }
        }

        private void PathUpdate(object sender, SelectionChangedEventArgs e)
        {
            bool enableCompileButtons = txtBranchName.SelectedIndex > 0;
            if (GetSelectedProject == null)
            {
                CompileCleanVS.IsEnabled = false;
                btnConfigIS.IsEnabled = false;
                btnConfigRapid.IsEnabled = false;
                btnResetConfigIS.IsEnabled = false;
                btnResetConfigRapid.IsEnabled = false;
                btnRunIS.IsEnabled = false;
                btnRunRapid.IsEnabled = false;
                btnLaunchVS.IsEnabled = false;
                btnLaunchVS_Is.IsEnabled = false;
                btnLaunchVS_Rapid.IsEnabled = false;
                return;
            }
            CompileCleanVS.IsEnabled = enableCompileButtons;
            btnConfigIS.IsEnabled = enableCompileButtons;
            btnConfigRapid.IsEnabled = enableCompileButtons;
            btnResetConfigIS.IsEnabled = enableCompileButtons;
            btnResetConfigRapid.IsEnabled = enableCompileButtons;
            btnRunIS.IsEnabled = enableCompileButtons;
            btnRunRapid.IsEnabled = enableCompileButtons;
            btnLaunchVS.IsEnabled = enableCompileButtons;
            btnLaunchVS_Is.IsEnabled = enableCompileButtons;
            btnLaunchVS_Rapid.IsEnabled = enableCompileButtons;

            ISPathSelected.Items.Clear();
            string iSGPath = Path.Combine(_Localrepo, GetSelectedProject, _utilsData.Items.FirstOrDefault(x => x.Key == "ISG_exeLocation").Value);
            ISPathSelected.Items.Add(iSGPath);
            ISPathSelected.SelectedIndex = 0;

            var versions = ((UtilityGenericData)txtBranchName.SelectedItem)?.Value.Split(",".ToCharArray(), StringSplitOptions.RemoveEmptyEntries);
            if (versions.Length > 0)
                TextCodisVersion.Items.Clear();
            foreach (var version in versions)
                TextCodisVersion.Items.Add(version);
            if (TextCodisVersion.Items.Count == 1)
                TextCodisVersion.SelectedIndex = 0;
            if (TextProjectPathSelected != null && TextProjectPathSelected.IsEnabled)
            {
                string thePath = Path.Combine(_Localrepo, GetSelectedProject, "Source", "Product");
                TextProjectPathSelected.Items.Clear();
                TextProjectPathSelected.Items.Add(thePath);
                TextProjectPathSelected.SelectedIndex = 0;
            }
            // Default select the latest 
            TextCodisVersion.SelectedIndex = TextCodisVersion.Items.Count-1;
            TextDBType.SelectedIndex = TextDBType.Items.Count - 1;
            CreateDirLink_Click(null, null);

            if(txtBranchName.SelectedItem.ToString().Contains("11"))
                btnUpdateReg.Visibility = Visibility.Visible;
            else
                btnUpdateReg.Visibility = Visibility.Hidden;


        }

        private void btnOpenFolder_Click(object sender, RoutedEventArgs e)
        {
            string path = TextProjectPathSelected.SelectedItem?.ToString();
            if (!Directory.Exists(path))
            {
                MessageBox.Show($"{TextProjectPathSelected.SelectedItem} is not existing.\r\nPlease get that vesion from TFS.", "Notice", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
            else
                Process.Start(path);
        }
        private void DisplaySQLText_Click(object sender, SelectionChangedEventArgs e)
        {
            if (DBCommonScript.SelectedIndex < 0)
            {
                if (txtSQLScript != null)
                    txtSQLScript.Text = "";
                return;
            }
            this.Cursor = System.Windows.Input.Cursors.Wait;
            txtSQLScript.Text = ((UtilityGenericData)DBCommonScript.SelectedItem)?.Value;
            txtSQLScript.Text = txtSQLScript.Text.Trim().Replace("  ", " ").Replace("\r\n", " ").Replace("\t", " ");
            Clipboard.SetDataObject(txtSQLScript.Text.Trim());
            this.Cursor = System.Windows.Input.Cursors.Arrow;
        }
        private void btnEditConfig_Click(object sender, RoutedEventArgs e)
        {
            myPopupEditConfig.IsOpen = true;
            myPopupEditConfig.VerticalOffset = -400;
            myPopupEditConfig.Width = 820;
            LoadConfigDropDownList();
        }

        private void btnLaunchSQL_Click(object sender, RoutedEventArgs e)
        {
            this.Cursor = System.Windows.Input.Cursors.Wait;
            try
            {
                var errorIfAny = Utils.RunSQL(txtSQLScript.Text, MainWindow.GetLocalRepo(), null, true);
                if (errorIfAny.Length > 0)
                {
                    MessageBox.Show(errorIfAny, "Exec SQL Status", MessageBoxButton.OK, MessageBoxImage.Information);
                    _viewModel.DisplayStatusMessage($"Exec SQL Status: ERROR.");
                }
                else
                {
                    //MessageBox.Show("Completed", "Exec SQL Status", MessageBoxButton.OK, MessageBoxImage.Information);
                    _viewModel.DisplayStatusMessage($"Exec SQL Status: SUCCESS.");
                }
            }
            catch (Exception ex)
            {
                _viewModel.DisplayStatusMessage($" Err {ex.Message}");
                _viewModel.PublishException(ex);
            }

            finally
            {
                this.Cursor = System.Windows.Input.Cursors.Arrow;
            }
        }

        private void btnbtnInstalDB_Click(object sender, RoutedEventArgs e)
        {            
            if (TextDBType.SelectedIndex < 0 || TextCodisVersion.SelectedIndex < 0)
            {
                MessageBox.Show("Please select a database type/version", "OOPs", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }

            if (TextCodisVersion.SelectedIndex < 0 || TextDBType.SelectedIndex < 0)
            {
                MessageBox.Show("Please select the Supporting Database Version", "Install DB Status", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }

            try
            {
                this.Cursor = System.Windows.Input.Cursors.Wait;
                StopAllTheAppServices(sender);               
                NameValueCollection param = new NameValueCollection();
                param.Add("BranchName", GetBranchName());
                param.Add("DatabaseName", "CODIS");
                param.Add("Lab", ((UtilityGenericData)TextDBType.SelectedItem)?.Value);
                param.Add("ServerName", "localhost");
                param.Add("CODISVersion_Major", TextCodisVersion.Text);

                var errorIfAny = Utils.RunPSFile(Path.Combine(_Localrepo,
                                                              "trunk",
                                                              "Scripts\\Builds\\TeamCityBuilds",
                                                              "RestoreLatestDBToLocalSQLInstance_TeamCity.ps1"), param);
                if (errorIfAny.Length > 0)
                {
                    MessageBox.Show(errorIfAny, "Install DB Status", MessageBoxButton.OK, MessageBoxImage.Warning);
                    _viewModel.DisplayStatusMessage($"Install DB Status: Failed.");
                    _viewModel.PopupFlyMessage($"Database {TextCodisVersion.Text} failed to Install.\r\nRetry now. ",
                                            MessageBoxType.Information, 10);
                }
                else
                {
                    _viewModel.PopupFlyMessage($"Database {TextCodisVersion.Text} Installed.",
                                            MessageBoxType.Information, 3);                    
                    _viewModel.DisplayStatusMessage($"Install DB Status: SUCCESS.");
                }
            }
            catch (Exception ex)
            {
                _viewModel.DisplayStatusMessage($" Err {ex.Message}");
                _viewModel.PublishException(ex);
                this.Cursor = System.Windows.Input.Cursors.Arrow;
                return;
            }
            // DefaultATDBSetting
            StringBuilder sb = new StringBuilder();
            foreach (UtilityGenericData data in _utilsData.Items.Where(x => x.Key == "DefaultATDBSetting"))
            {
                sb.Append(data.Value).Replace("???", TextCodisVersion.Text);
            }
            if (sb.Length > 0)
            {
                Utils.RunSQL(sb.ToString(), MainWindow.GetLocalRepo(), null, false);
            }
            this.Cursor = System.Windows.Input.Cursors.Arrow;
            LoadVSPathLastUsedVesion();
            _viewModel.PopupFlyMessage("Restored database completed.", MessageBoxType.Information, 2);
        }

        private string GetBranchName()
        {
            if (txtBranchName.Text != "Maple" &&
                txtBranchName.Text != "Larch" &&
                txtBranchName.Text != "Aspen")
                return "AT";
            return txtBranchName.Text;
        }

        private void btnUpdateReg_Click(object sender, RoutedEventArgs e)
        {
            UtilityGenericData data = _utilsData.Items.FirstOrDefault(x => x.Key == "PSScriptUpdateCODISVersion");
            var temp = data.Value.Replace("???", TextCodisVersion.Text);
            //MessageBox.Show("Please paste the script below in PowerShell / Runas Admin. \r\nSet-ItemProperty -Path 'HKLM:\\SOFTWARE\\CODIS' -Name 'Version' -Value $NewVersion", "Script Run In Powershell", MessageBoxButton.OK, MessageBoxImage.Warning);
            Clipboard.SetDataObject(temp);

            string fileToRunManually = Path.Combine(_MV, "UtilityData", "MakeCODISVersion" + TextCodisVersion.Text + ".reg");
            MessageBox.Show("Please execute the reg file in the location:" + fileToRunManually, "Script Run manually", MessageBoxButton.OK, MessageBoxImage.Information);

            if (!File.Exists(fileToRunManually))
            {
                using (var writer = File.CreateText(fileToRunManually))
                {
                    data = _utilsData.Items.FirstOrDefault(x => x.Key == "UPDVersionInRegistry");
                    var text = data.Value.Replace("???", TextCodisVersion.Text);
                    writer.WriteLine(text);
                }
            }
            FileInfo fileInfo = new FileInfo(fileToRunManually);
            if (!Directory.Exists(fileInfo.Directory.FullName))
            {
                _viewModel.DisplayStatusMessage($"{fileToRunManually} is not existing.");
            }
            else
            {
                Process.Start(fileInfo.Directory.FullName);
                _viewModel.PopupFlyMessage("A *.reg file was created for CODIS. \r\nHowever, CODIS 12 and up is not required. \r\nYou can ignore intalling the Registry Setting for CODIS", MessageBoxType.Information, 12);
            }

        }

        private void btnbtnRestoreDefault_Click(object sender, RoutedEventArgs e)
        {
            if (MessageBox.Show("This will delete you current configuration and revert all setting back to default", "Confirm Restore All Setting",
                MessageBoxButton.YesNo, MessageBoxImage.Information) == MessageBoxResult.No)
                return;
            // copy default over and reload
            new UtilDataContext().GetStream("CODISUtilGenericData.xml", true, null);
            TextVSVersion.Items.Clear();
            btnReload_Click(null, null);
            DBCommonScript.SelectedIndex = -1;
        }

        private void btnLaunchTc_Click(object sender, RoutedEventArgs e)
        {
            this.Cursor = System.Windows.Input.Cursors.Arrow;
            try
            {
                if (RunasAdmin())
                {
                    ProcessStartInfo info = new ProcessStartInfo("TestComplete.exe");// vsExePath, Path.Combine(path, "Codis.sln"));
                    info.UseShellExecute = true;
                    info.Verb = "runas";
                    Process.Start(info);
                }
                else
                {
                    MessageBox.Show("You are not running as Administrator", "Notice", MessageBoxButton.OK, MessageBoxImage.Warning);
                    Process.Start("TestComplete.exe");
                }
                if (Utils.StartServices("CASWinService"))
                {
                    Utils.StartServices("NGISSWinService");
                }
            }
            catch
            {
                _viewModel.DisplayStatusMessage($"Not able to open TestComplete.exe");
                MessageBox.Show("TestComplete is not installed", "Notice", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            finally
            {
                this.Cursor = System.Windows.Input.Cursors.Arrow;
            }
        }

        private void btnLaunchCd_Click(object sender, RoutedEventArgs e)
        {
            this.Cursor = System.Windows.Input.Cursors.AppStarting;

            _viewModel.PopupFlyMessage("Starting up the services.", MessageBoxType.Information);

            if (Utils.StartServices("CASWinService"))
            {
                Utils.StartServices("NGISSWinService");
                try
                {
                    string symbolicLinkD = Path.Combine(_Localrepo, "Trunk", "Source", "Product", "Debug", "CODIS.AnalystWorkbench.exe");
                    if (!File.Exists(symbolicLinkD))
                    {
                        throw new FileNotFoundException($"File {symbolicLinkD} not found for execution");
                    }
                    _viewModel.PopupFlyMessage("Starting up AWB.", MessageBoxType.Information, 2);
                    Process.Start(symbolicLinkD);
                }
                catch
                {
                    _viewModel.DisplayStatusMessage($"Not able to open TestComplete.exe");
                    MessageBox.Show("CODIS is not compiled", "Notice", MessageBoxButton.OK, MessageBoxImage.Error);
                    this.Cursor = System.Windows.Input.Cursors.Arrow;                    
                    return;
                }
                finally
                {
                    this.Cursor = System.Windows.Input.Cursors.Arrow;
                }
            }
            this.Cursor = System.Windows.Input.Cursors.Arrow;
        }

        private void btnLaunchSQLServer_Click(object sender, RoutedEventArgs e)
        {
            this.Cursor = System.Windows.Input.Cursors.AppStarting;
            try
            {
                UtilityGenericData data = _utilsData.Items.FirstOrDefault(x => x.Key == "SQLServerLocation");
                var fileToExecute = data.Value;
                ProcessStartInfo startInfo = new ProcessStartInfo(data.Value);
                Process processToExecute = new Process();

                startInfo.UseShellExecute = true;
                processToExecute.StartInfo = startInfo;
                if (!File.Exists(fileToExecute))
                {
                    _viewModel.DisplayStatusMessage($"File {fileToExecute} not found for execution");
                    return;
                }
                processToExecute.Start();

            }
            catch
            {
                _viewModel.DisplayStatusMessage($"Not able to open sql server (Ssms.exe)");
                MessageBox.Show("Not able to open sql server (Ssms.exe).Please update your Config file", "Notice", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            finally
            {
                this.Cursor = System.Windows.Input.Cursors.Arrow;
            }
        }

        private void btnCompileVS_Click(object sender, RoutedEventArgs e)
        {
            BuildProjectWithTheLatestVersion(sender, false, "PSScriptGetLatestCompileCODIS");
        }

        private void btnCompileCleanVS_Click(object sender, RoutedEventArgs e)
        {
            BuildProjectWithTheLatestVersion(sender, true, "PSScriptGetLatestCompileCODIS");
        }

        private void BuildProjectWithTheLatestVersion(object sender, bool isCleanToo, string key)
        {
            if (GetSelectedProject == null)
            {
                MessageBox.Show("Please select a project (Supporting Branch)", "OOPs", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }
            if (CheckIfMissingInstallation(_utilsData.Items.FirstOrDefault(x => x.Key == "tf_exe").Value, "TFS"))
            {
                MessageBox.Show($"This path {_utilsData.Items.FirstOrDefault(x => x.Key == "tf_exe").Value} does not exist\r\nInstall Instruction:\r\n Use Visual Studio to ==>Tools menu==> Get Tools Features ==> then select check box option \"Azure Development\" ==> install/modify.", "Notice", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }
            StopAllTheAppServices(sender);
            
            if (TextProjectPathSelected.SelectedItem?.ToString() == "" ||
                txtBranchName.SelectedIndex <= 0)
            {
                MessageBox.Show("Please select a Supporting Branch", "OOPs", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }
            string fileToRunManually = Path.Combine(_MV, "UtilityData", "buildTheLatestCode.ps1");
            string buildOption = isCleanToo ? "Clean,Build" : "Build";

            UtilityGenericData data = _utilsData.Items.FirstOrDefault(x => x.Key == key);
            string strCommand = data.Value.Replace("OptBuild???", buildOption);
            //if (key == "PSScriptGetLatestCompileCODIS")
            //{
            //    var resultMes = MessageBox.Show("Please Make sure only Support CODIS 12/13. Otherwise, Cancel NOW!", "Warning", MessageBoxButton.OKCancel, MessageBoxImage.Warning);
            //    if (resultMes != MessageBoxResult.OK)
            //    { return; }
            //}
            strCommand = strCommand.Replace("TrunkPath???", Path.Combine(_Localrepo, GetSelectedProject));
            strCommand = strCommand.Replace("CREPath???", Path.Combine(((UtilityGenericData)RapidPathSelected.SelectedValue).Name));

            strCommand = strCommand.Replace("???MSBuild_exe", _utilsData.Items.FirstOrDefault(x => x.Key == "MSBuild_exe"
                                                             && x.Name == ((UtilityGenericData)TextVSVersion.SelectedValue).Name).Value);
            strCommand = strCommand.Replace("???tf_exe", _utilsData.Items.FirstOrDefault(x => x.Key == "tf_exe").Value);

            using (var writer = File.CreateText(fileToRunManually))
            {
                writer.WriteLine(strCommand);
            }
            //get latest from tfs
            try
            {
                if (RunasAdmin())
                {
                    Process process = new Process();
                    ProcessStartInfo startInfo = new ProcessStartInfo();
                    startInfo.WindowStyle = ProcessWindowStyle.Maximized;
                    startInfo.FileName = _utilsData.Items.FirstOrDefault(x => x.Key == "powershell_iseLocation").Value;
                    startInfo.Arguments = fileToRunManually;
                    //+ "\r\n" + getlatest + "\r\n";
                    var view = startInfo.Arguments;
                    startInfo.UseShellExecute = true;
                    startInfo.Verb = "runas";
                    process.StartInfo = startInfo;
                    Process.Start(startInfo);
                }
                else
                {
                    _viewModel.PopupFlyMessage("You are not running the utility as Administrator.\r\nTry again using runas Administrator", MessageBoxType.Warning);
                }
            }
            catch (Exception ex)
            {
                var msg = ex.Message;
            }
        }

        private bool CheckIfMissingInstallation(string value, string source)
        {
            switch (source)
            {
                case "TFS":
                    if (!File.Exists(value))
                    {
                        if (source == "TFS")
                            MessageBox.Show($"This path {value} does not exist\r\nInstall Instruction:\r\n Use Visual Studio to ==>Tools menu==> Get Tools Features ==> then select check box option \"Azure Development\" ==> install/modify.", "Notice", MessageBoxButton.OK, MessageBoxImage.Warning);
                        else if (source == "PSE")
                            MessageBox.Show($"This path {value} does not exist\r\nInstall Instruction:\r\n Find the \"powershell_ise.exe\" in your local drive and update the config file (key \"powershell_iseLocation\")", "Notice", MessageBoxButton.OK, MessageBoxImage.Warning);
                        return true;
                    }
                    break;
                default:
                    MessageBox.Show($"This path {value} does not exist", "Notice", MessageBoxButton.OK, MessageBoxImage.Warning);
                    return true;
            }

            return false;
        }

        private void StopAllTheAppServices(object sender)
        {
            Utils.CloseApp("CODIS.AnalystWorkbench");
            Utils.CloseApp("Rapid.Workstation");
            CloseIISExpress();
            
            Thread.Sleep(1);
            Thread.Sleep(Utils.StopServices("NGISSWinService"));
            Thread.Sleep(Utils.StopServices("CASWinService"));
            if(sender is Button)
            {
                if(((Button)sender).Name != "btnInstalDB")
                    Utils.CloseApp("powershell_ise");
            }
        }

        private void btnConfigIS_Click(object sender, RoutedEventArgs e)
        {
            _viewModel.PopupFlyMessage("This will perform the following steps:\r\n1- Change ISG config file to disable HTTPs\r\n2- Change web.config in IS server.\r\n3- Link the debug directory to the IS.Server\bin.", MessageBoxType.Information, 20);
            if (GetSelectedProject == null)
                return;
            this.Cursor = System.Windows.Input.Cursors.Wait;
            //http://codistfs:8080/tfs/CODIS/CODIS/_sprints/taskboard/Automated%20Testing/CODIS/DMSS%20CODIS%2013/CODIS%2013%20Sprint%206%20-%20PI%202
            //into CODIS_AppConfigSettings VALUES('InteropService', 'url', 'http://localhost:64582', '') no need (not sure why)
            //Get latest ISG/CODIS
            string linkToFolder = Path.Combine(_Localrepo, GetSelectedProject, "Source", "Product", "IS.Server", "bin");
            string linkFromFolder = Path.Combine(_Localrepo, GetSelectedProject, "Source", "Product", "Debug", "IS.web");
            DirectoryInfo di = new DirectoryInfo(linkToFolder);
            if (di.Exists)
                Directory.Delete(linkToFolder, true);
            Thread.Sleep(100);
            //mklink 
            CreateSymbolicLink(linkToFolder,
                                   linkFromFolder,
                                   SymbolicLink.Directory);

            var ISGConfigFileName = Path.Combine(_Localrepo, GetSelectedProject,
                                                _utilsData.Items.FirstOrDefault(x => x.Key == "ISG_exeLocation").Value, "CISG.exe");
            if (!File.Exists(ISGConfigFileName))
            {
                _viewModel.DisplayStatusMessage($"You have not compile ISG using 64bits processor. Retry now.");
                this.Cursor = System.Windows.Input.Cursors.Arrow;
                return;
            }
            FileInfo fi = new FileInfo(ISGConfigFileName);
            //Update _Localrepo\Trunk\CISG\CISG\bin\Debug\CISG.exe.config (disable SSL)
            ChangeProjectConfig(fi.FullName, "ISG");
            ISGConfigFileName = Path.Combine(_Localrepo, GetSelectedProject, "Source", "Product", "IS.Server");
            //Update _Localrepo\Trunk\Source\Product\IS.Server\web.config (disable SSL)
            fi = new FileInfo(ISGConfigFileName);
            ChangeProjectConfig(fi.FullName, "IS");
        }

        private void ChangeProjectConfig(string rootPath, string configSource, bool isUndo = false)
        {
            try
            {
                _ps = PowerShell.Create();
                string path = Path.Combine(Environment.CurrentDirectory, "PsScriptLib", @"TextReplace.ps1");
                //PS Script file has to be running no error. No error handle in this code.
                string scriptFile = File.ReadAllText(path);
                _ps.Commands.Clear();
                _ps.AddScript(scriptFile);
                //_ps.Streams.Verbose.DataAdded += new EventHandler<DataAddedEventArgs>(DataCopyStatusAdded);

                switch (configSource)
                {
                    case "ISG":
                        {
                            CreateParametersSearchReplace(rootPath.Replace("CISG.exe", ""), "*exe.config", "key=\"SSLRequired\" value=\"True\"", "key=\"SSLRequired\" value=\"False\"");

                            break;
                        }
                    case "RapidServer":
                        {
                            if (isUndo)
                            {
                                //CreateParametersSearchReplace(Path.Combine(rootPath), "*.config", "http:", "https:");
                                //_ps.Commands.Clear();
                                //_ps.AddScript(scriptFile);
                                //CreateParametersSearchReplace(rootPath, "*.config", "requireSSL=\"false\"", "requireSSL=\"true\"");
                                Utils.UndoCheckOutFromTFS(Path.Combine(rootPath, "*.Config"), true);
                                break;
                            }
                            CreateParametersSearchReplace(rootPath, "*.config", "https:", "http:");
                            _ps.Commands.Clear();
                            _ps.AddScript(scriptFile);
                            CreateParametersSearchReplace(rootPath, "*.config", "requireSSL=\"true\"", "requireSSL=\"false\"");
                            break;
                        }
                    case "RapidW":
                        {
                            if (isUndo)
                            {
                                //CreateParametersSearchReplace(Path.Combine(rootPath, "Rapid.Workstation"), "*pp.config", "file=\"common.config\"", "file=\"../../../../common.config\"");
                                //_ps.Commands.Clear();
                                //_ps.AddScript(scriptFile);
                                // CreateParametersSearchReplace(rootPath, "*on.config", "http:", "https:");
                                Utils.UndoCheckOutFromTFS(Path.Combine(rootPath, "*.Config"), true);
                                break;
                            }
                            CreateParametersSearchReplace(Path.Combine(rootPath, "Rapid.Workstation"), "*pp.config", "../../../../", "");
                            _ps.Commands.Clear();
                            _ps.AddScript(scriptFile);
                            CreateParametersSearchReplace(rootPath, "*on.config", "https:", "http:");
                            break;
                        }
                    case "IS":
                        {
                            if (isUndo)
                            {
                                //CreateParametersSearchReplace(rootPath, "*Web.config", "requireSSL=\"false\"", "requireSSL=\"true\"");
                                //_ps.Commands.Clear();
                                //_ps.AddScript(scriptFile);
                                //CreateParametersSearchReplace(rootPath, "*Web.config", "allowUnlisted=\"true\"", "allowUnlisted=\"false\"");
                                //_ps.Commands.Clear();
                                //_ps.AddScript(scriptFile);
                                CreateParametersSearchReplace(Path.Combine("C:\\Program Files", "IIS Express", "AppServer"),
                                    "*pplicationhost.config", "windowsAuthentication enabled=\"true\"", "windowsAuthentication enabled=\"false\"");

                                Utils.UndoCheckOutFromTFS(Path.Combine(rootPath, "Web.Config"));
                            }
                            else
                            {
                                CreateParametersSearchReplace(rootPath, "*Web.config", "requireSSL=\"true\"", "requireSSL=\"false\"");
                                _ps.Commands.Clear();
                                _ps.AddScript(scriptFile);
                                CreateParametersSearchReplace(rootPath, "*Web.config", "allowUnlisted=\"false\"", "allowUnlisted=\"true\"");
                                _ps.Commands.Clear();
                                _ps.AddScript(scriptFile);
                                CreateParametersSearchReplace(Path.Combine("C:\\Program Files", "IIS Express", "AppServer"),
                                    "*pplicationhost.config", "windowsAuthentication enabled=\"false\"", "windowsAuthentication enabled=\"true\"");
                            }
                            break;
                        }
                }
            }
            catch (Exception ex)
            {
                _viewModel.DisplayStatusMessage($" Err {ex.Message}");
                _viewModel.PublishException(ex);
            }
            finally
            {
                _ps.Stop();
                _ps.Dispose();
                this.Cursor = System.Windows.Input.Cursors.Arrow;
            }
        }

        private void CreateParametersSearchReplace(string strPathFile, string strExt, string oldVal, string newVal)
        {
            if (Path.HasExtension(strExt))
            {
                _ps.AddParameter("path", strPathFile);
                _ps.AddParameter("ext", strExt);
                _ps.AddParameter("txtOld", oldVal);
                _ps.AddParameter("txtNew", newVal);
                Collection<PSObject> collection = _ps.Invoke();
            }
            else
            {
                _viewModel.DisplayStatusMessage($" You dont have IIS express installed. IIS is NOT created.");
            }
        }

        private void btnCompileIS_Click(object sender, RoutedEventArgs e)
        {
            BuildProjectWithTheLatestVersion(sender, false, "PSScriptGetLatestCompileISG");
        }

        private void btnRunIS_Click(object sender, RoutedEventArgs e)
        {
            _viewModel.PopupFlyMessage("Processing 3 steps:\r\n1- Start Services\r\n2- Create Local IIS Express process using port 64582.\r\n3-Start ISG application", MessageBoxType.Information, 10);
            if (GetSelectedProject == null)
                return;
            this.Cursor = System.Windows.Input.Cursors.Wait;

            if (Utils.StartServices("CASWinService"))
            {
                Utils.StartServices("NGISSWinService");
            }
            StartUpIISExpressLocal(Path.Combine(_Localrepo, GetSelectedProject, "Source", "Product", "IS.Server"));
            var asgExePath = Path.Combine(_Localrepo, GetSelectedProject, _utilsData.Items.FirstOrDefault(x => x.Key == "ISG_exeLocation").Value, "CISG.exe");
            if (!File.Exists(asgExePath))
            {
                _viewModel.DisplayStatusMessage($"You have not compile ISG using 64bits processor. Retry now.");
                return;
            }
            try
            {
                if (RunasAdmin())
                {
                    ProcessStartInfo info = new ProcessStartInfo(asgExePath);
                    info.UseShellExecute = true;
                    info.Verb = "runas";
                    Process.Start(info);
                }
                else
                {
                    MessageBox.Show("You are not running ISG as Administrator", "Notice", MessageBoxButton.OK, MessageBoxImage.Warning);
                    Process.Start(asgExePath);
                }
            }
            catch
            {
                _viewModel.DisplayStatusMessage($"Not able to open ISG in {asgExePath}");
                return;
            }
            finally
            {
                this.Cursor = System.Windows.Input.Cursors.Arrow;
                _viewModel.DisplayStatusMessage($"Make sure you use URL= localhost:64582 to connect from ISG module.");
            }
            //string codisBinFolder = Path.Combine(_Localrepo, GetSelectedProject, "Source", "Product", "IS.Server");

            //ServerManager iisManager = new ServerManager();
            //while(iisManager.Sites.Count>0)
            //    iisManager.Sites.RemoveAt(0);
            //iisManager.Sites.Add("Local", "http", "*:80:", codisBinFolder);
            //var test = iisManager.Sites[0];
            //var appPool = iisManager.ApplicationPools.Where(p => p.Name == "DefaultAppPool").FirstOrDefault();
            //appPool.Enable32BitAppOnWin64 = true;
            //iisManager.CommitChanges();

        }

        private static bool RunasAdmin()
        {
            bool isAdmin;
            WindowsIdentity identity = WindowsIdentity.GetCurrent();
            WindowsPrincipal principal = new WindowsPrincipal(identity);
            isAdmin = principal.IsInRole(WindowsBuiltInRole.Administrator);
            return isAdmin;
        }

        private void StartUpIISExpressLocal(string WebHostPath, int port = 64582)
        {
            var p = Process.GetProcessesByName("iisexpress", ".");
            if (p != null && p.Count() > 0)
            {
                return;
            }
            string asgcommansPath = Path.Combine(_MV, "UtilityData", "IS.cmd");
            if (File.Exists(asgcommansPath))
                File.Delete(asgcommansPath);

            File.WriteAllText(asgcommansPath, @"cd C:\Program Files\IIS Express\
iisexpress /path:" + WebHostPath + "\\ /port:" + port);
            Path.Combine(_Localrepo, GetSelectedProject, "Source", "Product", "IS.Server");
            try
            {
                if (RunasAdmin())
                {
                    ProcessStartInfo info = new ProcessStartInfo(asgcommansPath);
                    info.UseShellExecute = true;
                    info.Verb = "runas";
                    Process.Start(info);
                }
                else
                {
                    MessageBox.Show("You are not running ISG as Administrator", "Notice", MessageBoxButton.OK, MessageBoxImage.Warning);
                }
            }
            catch
            {
                _viewModel.DisplayStatusMessage($"Not able to open ISG in {asgcommansPath}");
                return;
            }
            finally
            {
                _viewModel.DisplayStatusMessage("IS started ...");
            }
        }

        private void btnResetIS_Click(object sender, RoutedEventArgs e)
        {
            _viewModel.PopupFlyMessage("This will perform 2 steps:\r\n1- Undo ISG config file to disable HTTPs\r\n2- Undo Change web.config in IS server.", MessageBoxType.Information, 20);
            var ISGConfigFileName = Path.Combine(_Localrepo, GetSelectedProject, "Source", "Product", "IS.Server");
            FileInfo fi = new FileInfo(ISGConfigFileName);
            ChangeProjectConfig(fi.FullName, "IS", true);
              MessageBox.Show("IS web config undone from in TFS.", "Notice", MessageBoxButton.OK, MessageBoxImage.Information);
        }
        /*For Rapid*/

        private void btnResetConfigRapid_Click(object sender, RoutedEventArgs e)
        {
            var asgExePath = Path.Combine(_Localrepo, GetSelectedProject, "Rapid", "src", "Rapid.Server", "Rapid.Server");
            ChangeProjectConfig(asgExePath, "RapidServer", true);
            //rapidW
            asgExePath = Path.Combine(((UtilityGenericData)RapidPathSelected.SelectedValue).Name, "Source\\Rapid.Workstation");
            FileInfo fi = new FileInfo(asgExePath + "\\Common.config");
            if (!fi.Exists)
            {
                return;
            }
            ChangeProjectConfig(asgExePath, "RapidW", true);
            MessageBox.Show("Rapid configurations undone.", "Notice", MessageBoxButton.OK, MessageBoxImage.Information);
        }

        private void btnConfigRapid_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                this.Cursor = System.Windows.Input.Cursors.Wait;
                //C:\Proj\R\CODIS\Trunk\Source\Product\Debug\Rapid.web
                //IS part            
                StopAllTheAppServices(sender);
                string linkFromFolder = Path.Combine(_Localrepo, GetSelectedProject, "Source", "Product", "Debug", "Rapid.web");
                string linkToFolder = Path.Combine(_Localrepo, GetSelectedProject, "Rapid", "src", "Rapid.Server", "Rapid.Server", "bin");
                DirectoryInfo di = new DirectoryInfo(linkToFolder);
                if (di.Exists)
                    Directory.Delete(linkToFolder, true);
                Thread.Sleep(100);
                var asgExePath = Path.Combine(_Localrepo, GetSelectedProject, "Rapid", "src", "Rapid.Server", "Rapid.Server");
                ChangeProjectConfig(asgExePath, "RapidServer", false);
                //mklink 
                CreateSymbolicLink(linkToFolder, linkFromFolder, SymbolicLink.Directory);
                //rapidW
                asgExePath = Path.Combine(((UtilityGenericData)RapidPathSelected.SelectedValue).Name, "Source\\Rapid.Workstation");
                FileInfo fi = new FileInfo(asgExePath + "\\Common.config");

                if (!fi.Exists)
                {
                    MessageBox.Show("Rapid need to be get the latest first.", "Notice", MessageBoxButton.OK, MessageBoxImage.Information);
                    this.Cursor = System.Windows.Input.Cursors.Arrow;
                    return;
                }
                ChangeProjectConfig(asgExePath, "RapidW", false);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Rapid Error.\r\n{ex.Message}", "Notice", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            finally
            {
                this.Cursor = System.Windows.Input.Cursors.Arrow;
            }

        }
        //for rapid later...
        static void RunInteractive(ServiceBase[] servicesToRun)
        {
            Console.WriteLine("Services running in interactive mode.");
            Console.WriteLine();

            MethodInfo onStartMethod = typeof(ServiceBase).GetMethod("OnStart",
                BindingFlags.Instance | BindingFlags.NonPublic);
            foreach (ServiceBase service in servicesToRun)
            {
                Console.Write("Starting {0}...", service.ServiceName);
                onStartMethod.Invoke(service, new object[] { new string[] { } });
                Console.Write("Started");
            }

            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine(
                "Press any key to stop the services and end the process...");
            Console.ReadKey();
            Console.WriteLine();

            MethodInfo onStopMethod = typeof(ServiceBase).GetMethod("OnStop",
                BindingFlags.Instance | BindingFlags.NonPublic);
            foreach (ServiceBase service in servicesToRun)
            {
                Console.Write("Stopping {0}...", service.ServiceName);
                onStopMethod.Invoke(service, null);
                Console.WriteLine("Stopped");
            }

            Console.WriteLine("All services stopped.");
            // Keep the console alive for a second to allow the user to see the message.
            Thread.Sleep(1000);
        }
        private void btnRunRapid_Click(object sender, RoutedEventArgs e)
        {
            //MessageBox.Show($"This module is not ready.\r\nConnection to RapidServer is still not working and more work required like:\r\nRun File Watcher service manually from RapidWorkstation");
        
            _viewModel.DisplayStatusMessage("Working on ....");

            this.Cursor = System.Windows.Input.Cursors.Wait;
            var asgExePath = Path.Combine(((UtilityGenericData)RapidPathSelected.SelectedValue).Name, "Source\\Rapid.Workstation\\Rapid.Workstation\\bin\\x64\\Debug");
            FileInfo fi = new FileInfo(asgExePath + "\\Common.config");
            Utils.CloseApp("Rapid.Workstation");
            if (!fi.Exists)
            {
                MessageBox.Show("Rapid need to be compile first.", "Notice", MessageBoxButton.OK, MessageBoxImage.Information);
                this.Cursor = System.Windows.Input.Cursors.Arrow;
                return;
            }
            ChangeProjectConfig(asgExePath, "RapidServer", false);

            asgExePath = Path.Combine(((UtilityGenericData)RapidPathSelected.SelectedValue).Name, "Source\\Rapid.Workstation\\Rapid.Workstation\\bin\\x64\\Debug");
            fi = new FileInfo(asgExePath + "\\Rapid.Workstation.exe.config");
            if (fi.Exists)
            {
                ChangeProjectConfig(asgExePath, "RapidW", false);
            }
            //Sc.exe create CODISFileWatcher start= demand DisplayName=CODISFileWatcher binPath= C:\Proj\R\CRE\Trunk\Source\Rapid.Workstation\Rapid.Workstation\bin\x64\Debug\CRE.FileWatcherService.exe obj=CODISDMSS\GDISSQLServer password=C0dis@ecs
            //System.Diagnostics.Process.Start("Net Start CODISFileWatcher");
            //ServiceBase[] servicesToRun;
            //servicesToRun = new ServiceBase[]
            //{
            //     Assembly assem = typeof(xxx).Assembly;
            //Person p = (xxx)assem.CreateInstance(".exe");
            //new FileWatcherService()
            //};
            //if (Environment.UserInteractive)
            //{
            //    RunInteractive(servicesToRun);
            //}

            if (Utils.StartServices("CASWinService"))
            {
                Utils.StartServices("NGISSWinService");
            }
            StartUpIISExpressLocal(Path.Combine(_Localrepo, GetSelectedProject, "Rapid", "src", "Rapid.Server", "Rapid.Server"), 64581);
             asgExePath = Path.Combine(((UtilityGenericData)RapidPathSelected.SelectedValue).Name, "Source\\Rapid.Workstation\\Rapid.Workstation\\bin\\x64\\Debug\\Rapid.Workstation.exe");
            if (!File.Exists(asgExePath))
            {
                _viewModel.DisplayStatusMessage($"You have not compile Rapid using 64bits processor. Retry later.");
                return;
            }
            try
            {
                if (RunasAdmin())
                {
                    ProcessStartInfo info = new ProcessStartInfo(asgExePath);
                    info.UseShellExecute = true;
                    info.Verb = "runas";
                    Process.Start(info);
                }
                else
                {
                    MessageBox.Show("You are not running Rapid as Administrator", "Notice", MessageBoxButton.OK, MessageBoxImage.Warning);
                    Process.Start(asgExePath);
                }
            }
            catch
            {
                _viewModel.DisplayStatusMessage($"Not able to open Rapid in {asgExePath}");
                return;
            }
            finally
            {
                this.Cursor = System.Windows.Input.Cursors.Arrow;
                _viewModel.DisplayStatusMessage($"Rapid Workstation module is opening.");
            }
        }

        private void btnCompileRapid_Click(object sender, RoutedEventArgs e)
        {
            // create 3 required folders
            if (!Directory.Exists("C:\\ProgramData\\CRE\\Data"))
            {
                Directory.CreateDirectory("C:\\ProgramData\\CRE\\Data");
            }
            if (!Directory.Exists("C:\\Rapid Import\\Drop"))
            {
                Directory.CreateDirectory("C:\\Rapid Import\\Drop");
            }
            if (!Directory.Exists("C:\\Rapid Import\\Processed"))
            {
                Directory.CreateDirectory("C:\\Rapid Import\\Processed");
            }
            if (!Directory.Exists("C:\\Rapid Import\\OriginXMLFiles"))
            {
                Directory.CreateDirectory("C:\\Rapid Import\\OriginXMLFiles");
            }
            // get the latest code and compile
            BuildProjectWithTheLatestVersion(sender, false, "PSScriptGetLatestCompileRapid");
        }

        private void PathSelectedViewPath(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            string path = ((ComboBox)sender).SelectedItem?.ToString();
            if (!Directory.Exists(path))
            {
                MessageBox.Show($"Path {path} is not existing.\r\nPlease get that vesion from TFS and compile the project.", "Notice", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
            else
                Process.Start(path);
        }

        private void btnLaunchVS_Click(object sender, RoutedEventArgs e)
        {
            _viewModel.PopupFlyMessage($"Make sure before you compile:\r\nCheck your current setting\r\nDid you switch to the right code and database version?.", MessageBoxType.Information);
            string strSolutionName = "CODIS.sln";
            string path = TextProjectPathSelected.SelectedItem?.ToString();
            OpenProjectInVisualStudio(strSolutionName, path);
        }

        private void btnLaunchVS_IS_Click(object sender, RoutedEventArgs e)
        {
            _viewModel.PopupFlyMessage($"Opening CISG.sln with Visual Studio", MessageBoxType.Information );
            string strSolutionName = "CISG.sln";
            string path = ISPathSelected.SelectedItem?.ToString();
            if (path == null)
                MessageBox.Show($"Please select a supporting branch.", "Notice", MessageBoxButton.OK, MessageBoxImage.Information);
            path = path.Replace("bin\\x64\\Debug", "");
            if (!File.Exists(path + "CISG.sln"))
                strSolutionName = "CISG.csproj";
            OpenProjectInVisualStudio(strSolutionName, path);
        }

        private void btnLaunchVS_rapid_Click(object sender, RoutedEventArgs e)
        {
            _viewModel.PopupFlyMessage($"Opening Rapid.Workstation.sln with Visual Studio", MessageBoxType.Information);
            string strSolutionName = "Rapid.Workstation.sln";
            string path = ((UtilityGenericData)RapidPathSelected.SelectedValue).Name;
            if (string.IsNullOrEmpty(path))
                return;
            path = Path.Combine(path, "Source", "Rapid.Workstation");
            OpenProjectInVisualStudio(strSolutionName, path, false);
        }

        /// <summary>
        /// Open this tool (hard coded)
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void LaunchThisTool(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            if (File.Exists("C:\\Proj\\R\\CODIS\\Trunk\\Source\\Tools\\WPF.PSEmbedding\\WPF.PSEmbedding.sln"))
                OpenProjectInVisualStudio("WPF.PSEmbedding.sln", "C:\\Proj\\R\\CODIS\\Trunk\\Source\\Tools\\WPF.PSEmbedding");
        }

        private void OpenProjectInVisualStudio(string strSolutionName, string path, bool dependancyCheck = true)
        {
            this.Cursor = System.Windows.Input.Cursors.Wait;
            if (dependancyCheck && (TextVSVersion.SelectedIndex < 0 || TextProjectPathSelected.SelectedIndex < 0))
            {
                MessageBox.Show("Please select the right Version of VS and Project!", "Notice", MessageBoxButton.OK, MessageBoxImage.Information);
                this.Cursor = System.Windows.Input.Cursors.Arrow;
                return;
            }

            if (!Directory.Exists(path))
            {
                _viewModel.DisplayStatusMessage("Please get this version from TFS");
                this.Cursor = System.Windows.Input.Cursors.Arrow;
                return;
            }
            //if (TextVSVersion.Items.Count == 0)
            //{
            //    UtilityGenericData newItem = new UtilityGenericData();
            //    newItem.Key = "VSPath";
            //    newItem.Name = "Curent version";
            //    newItem.Value = _utilsData.Items.FirstOrDefault(x => x.Key == "VSLocation" && x.Name == "VS 2022").Value;
            //    TextVSVersion.Items.Add(newItem);
            //    TextVSVersion.SelectedIndex = 0;
            //}

            string vsExePath = ((UtilityGenericData)TextVSVersion.SelectedValue).Value;
            if (!File.Exists(vsExePath))
            {
                MessageBox.Show($"{vsExePath}\r\n\r\nVisual Studio Path above is NOT valid. \r\nPlease edit Configuration file now.", "Notice", MessageBoxButton.OK, MessageBoxImage.Warning);
                btnEditConfig_Click(null, null);
                this.Cursor = System.Windows.Input.Cursors.Arrow;
                return;
            }

            try
            {
                if (RunasAdmin())
                {
                    ProcessStartInfo info = new ProcessStartInfo(vsExePath, Path.Combine(path, strSolutionName));
                    info.UseShellExecute = true;
                    info.Verb = "runas";
                    Process.Start(info);
                }
                else
                {
                    MessageBox.Show("You are not running as Administrator", "Notice", MessageBoxButton.OK, MessageBoxImage.Warning);
                    Process.Start(path);
                }
            }
            catch
            {
                _viewModel.DisplayStatusMessage($"Not able to open {strSolutionName} in {vsExePath}");
                return;
            }
            finally
            {
                this.Cursor = System.Windows.Input.Cursors.Arrow;
            }
        }

        private void btnLaunchDSG_Click(object sender, RoutedEventArgs e)
        {
            var temp = _utilsData.Items.Where(x => x.Key == "JetBrainRider").FirstOrDefault();
            if (temp == null)
            {
                MessageBox.Show("You have not installed JetBrainRider to run this app", "Notice", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }
            var vsExePath = temp.Value;
            var strSolutionName = Path.Combine(_Localrepo, txtBranchName.Text, "Source", "Tools", "DataSetGenerator", "DataSetGenerator.sln");
            if (!File.Exists(strSolutionName))
            {
                MessageBox.Show($"DataSetGenerator is not install in this path:\r\n{strSolutionName}", "Notice", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }
            try
            {
                if (RunasAdmin())
                {
                    ProcessStartInfo info = new ProcessStartInfo(vsExePath, strSolutionName);
                    info.UseShellExecute = true;
                    info.Verb = "runas";
                    Process.Start(info);
                }
                else
                {
                    MessageBox.Show("You are not running as Administrator", "Notice", MessageBoxButton.OK, MessageBoxImage.Warning);
                    Process.Start(vsExePath);
                }
            }
            catch
            {
                _viewModel.DisplayStatusMessage($"Not able to open JetBrainRider please correct Rider exe path {vsExePath}");
                return;
            }
            finally
            {
                this.Cursor = System.Windows.Input.Cursors.Arrow;
            }
        }

        private void btnHelp_Click(object sender, RoutedEventArgs e)
        {
            string path = Path.Combine(Environment.CurrentDirectory, "PsScriptLib", "note.docx");
            Process.Start(path);
        }

        private void btnSaveConfig_Click(object sender, RoutedEventArgs e)
        {
            UtilityGenericData newRow = new UtilityGenericData();
            newRow.Name = txtConfigName.Text;
            newRow.Value = txtConfigValue.Text;
            newRow.Key = txtConfigKey.Text;
            string path = Path.Combine(_MV, "UtilityData", "CODISUtilGenericData.xml");
            int status = _utilsData.UpdateRow(newRow, path);
            
            btnReload_Click(null, null);
            if (status == 1)
                _viewModel.PopupFlyMessage($"{newRow.Name} is Updated.", MessageBoxType.Information);
            else if (status == 2)
                _viewModel.PopupFlyMessage($"{newRow.Name} is added.", MessageBoxType.Information);
            else
                _viewModel.PopupFlyMessage($"No change.", MessageBoxType.Information);
        }
        private void btnDeleteConfig_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtConfigKey.Text))
                return;
            UtilityGenericData newRow = new UtilityGenericData();
            newRow.Name = txtConfigName.Text;
            newRow.Value = txtConfigValue.Text;
            newRow.Key = txtConfigKey.Text;
            string path = Path.Combine(_MV, "UtilityData", "CODISUtilGenericData.xml");
            int status = _utilsData.DeleteRow(newRow, path);
            btnReload_Click(null, null);
            if (status == 0)
                _viewModel.PopupFlyMessage($"{newRow.Key} - {newRow.Name} is not found.", MessageBoxType.Information);
            else if (status == 1)
                _viewModel.PopupFlyMessage($"{newRow.Name} was Deleted.", MessageBoxType.Information);
        }

        private void btnCloseConfig_Click(object sender, RoutedEventArgs e)
        {
            myPopupEditConfig.IsOpen = false;
        }

        private void cbxConfigKeys_select(object sender, SelectionChangedEventArgs e)
        {
            UtilityGenericData selectedItem = cbxConfigKeys.SelectedItem as UtilityGenericData;
            if (selectedItem == null)
                return;
            txtConfigName.Text = selectedItem.Name;
            txtConfigValue.Text = selectedItem.Value;
            txtConfigKey.Text = selectedItem.Key;
        }
        /// <summary>
        /// self document code.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ShowFlyoutMessage(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            string btName = "";
            if (sender is Control)
            {
                var name = sender as Control;
                btName = name.Name;
            }
            switch(btName)
            {
                case "txtBranchName":
                    _viewModel.PopupFlyMessage("Activate a branch or a version of CODIS to work on.\r\nBefore the branch is activate:\r\n All running powershell windows will be stopped.\r\n All running CODIS related processes will be terminated.\r\n The Activated branch will remain Active until you switch to another branch.\r\nAssuming you have done the following:\r\n1- Mapping TFS path: CODISTFS\\CODIS to your local C:\\Proj\\R\\CODIS.\r\n2- The values of MV and localrepo are set in the configuration of this app.\r\n    Click the help button to see how to change this.\r\n3- Have the full Access privilege to the code paths.", MessageBoxType.Information, 40);
                    break;
                case "btnInstalDB":
                    _viewModel.PopupFlyMessage($"Restore the database {TextDBType.SelectedItem?.ToString()} version {TextCodisVersion.SelectedItem?.ToString()} , following the process below:\r\n1- Stop All CODIS services and any AWB windows.\r\n2- Get the selected database version from the Artifactory for {txtBranchName.SelectedItem?.ToString()}.\r\n3- Inject custom scripts after database is restore.\r\nClick the help button for details. (Key work \"DefaultATDBSetting\")", MessageBoxType.Information, 30);
                    break;
                case "btnLaunchCd":
                    _viewModel.PopupFlyMessage($"Open AWB after code was compiled before.\r\n1- Start CAS and NGISS if not already start\r\n2- Use code in <{txtBranchName.SelectedItem?.ToString()}> folder to launch AWB.", MessageBoxType.Information, 30);
                    break;
                case "btnUpdateReg":
                    _viewModel.PopupFlyMessage("Only apply when running CODIS 11 or earlier.\r\n1- A Registry file will be created base on the selected CODIS version\r\n2- The folder that contains the registry file will be opened.\r\nNote:\r\nDue to the security policy restriction, the registry update will need to do manually.\r\nSo addition steps need to be performed:\r\na- Open the Registry editor\r\nb- Import the registry file just created in the opening folder.\r\nThe Database version will be set in registry matching with CODIS code version", MessageBoxType.Information, 40);
                    break;
                case "btnLaunchVS":
                    _viewModel.PopupFlyMessage("Open the selected CODIS solution with Admin privilege.\r\nUsing the Visual studio version selected.", MessageBoxType.Information, 30);
                    break;
                case "CompileCleanVS":
                    _viewModel.PopupFlyMessage("Compile the solusion:\r\nA popup Powershell window opens with prepopulated script based on your select.\r\nPlease choose the right Visual Studio version before proceeding.\r\n1- All CODIS services and any AWB windows will be terminated.\r\n2- Get the latest code from TFS. \r\n3- Use MSBuild to compile the selected project\r\nNote:\r\nYou can change the script to compile the way you want.\r\nMerging code if your local have a newer version, and can be performed in Visual Studio only.", MessageBoxType.Information, 30);
                    break;                
                case "TextCodisVersion":
                    _viewModel.PopupFlyMessage("Select the Database version from the CODIS Artifactory that would match the code version", MessageBoxType.Information, 5);
                    break;
                case "TextDBType":
                    _viewModel.PopupFlyMessage("Select the supported database type from the CODIS Artifactory", MessageBoxType.Information, 2);
                    break;
                case "TextVSVersion":
                    _viewModel.PopupFlyMessage("Select the Visual studio version that is compartible with the selected code version.\r\nNote:\r\nVS-2022 works for CODIS 13\r\nVS-2019 work for prior versions.\r\nBut you required to have the right Crystal Report and Dev-Express installed prior.", MessageBoxType.Information, 25);
                    break;
                case "ISPathSelected":
                    _viewModel.PopupFlyMessage($"ISG Project path\r\nSelect automatically when the branch is switched.\r\nCurrently this is <{txtBranchName.SelectedItem?.ToString()}> version.", MessageBoxType.Information);
                    break;
                case "RapidPathSelected":
                    _viewModel.PopupFlyMessage("Rapid project location.\r\nThis can be changed in the configuration or can be typed in manually", MessageBoxType.Information, 30);
                    break;
                case "btnConfigIS":
                    _viewModel.PopupFlyMessage("To Configure ISG, make sure you have right ISG/CODIS code\r\nThe app will to enable running ISG locally for debuging IS services.\r\nSteps will be done:\r\n1- Update the app.comfig and the web.config of ISG and IS.\r\n2- Make Linked directory so the CODIS\bin folder can correctly referenced by IS project", MessageBoxType.Information, 30);
                    break;
                case "btnRunIS":
                    _viewModel.PopupFlyMessage("ONLY work after you done with ISG Configuration and ISG\\CODIS compilation.\r\nThis will run the executable in ISG >> Bin folder\r\nStart up IIS express with the right port.\r\nMake sure you have the set of XML data and IS services enabled.", MessageBoxType.Information, 30);
                    break;
                case "btnResetConfigIS":
                    _viewModel.PopupFlyMessage("Undo IS / ISG configuration.\r\nOnly undo the code that was changed by this tool. \r\nNote:\r\n Do not check in the config until you undo the configuration", MessageBoxType.Information, 30);
                    break;
                case "btnLaunchVS_Is":
                    _viewModel.PopupFlyMessage($"Open ISG project solution in {txtBranchName.SelectedItem?.ToString()}", MessageBoxType.Information, 2);
                    break;
                case "btnConfigRapid":
                    _viewModel.PopupFlyMessage("Currently partially Completed. \r\n2 steps done are:\r\n1- Create Drop folders\r\n2-Config files update to avoid HTTPs. \r\nAdditional steps are required.", MessageBoxType.Information, 30);
                    break;
                case "btnResetConfigRapid":
                    _viewModel.PopupFlyMessage("Undo Rapid configuration.\r\nOnly undo the code that was changed by this tool. \r\nNote:\r\n Do not check in the config until you undo the configuration", MessageBoxType.Information, 30);
                    break;
                case "btnRunRapid":
                    _viewModel.PopupFlyMessage("Full functioning ONLY after you done with Rapid Configuration and CODIS compilation. \r\nAlso, there are number of options to set prior depend on the xml data", MessageBoxType.Information, 30);
                    break;
                case "btnLaunchVS_Rapid":
                    _viewModel.PopupFlyMessage("Open the selected Rapid project solution in Visual Studio", MessageBoxType.Information, 2);
                    break;
                case "DBCommonScript":
                    _viewModel.PopupFlyMessage("Frequently used SQL scripts like:\r\n1-Enable/Disable services for IS\r\n2-Add user to CODIS database\r\n3-Customized SQL scripts can be add via Edit Config. (click Help for more details)", MessageBoxType.Information, 30);
                    break;
                case "btnLaunchSQL":
                    _viewModel.PopupFlyMessage("Excute the predefined SQL selected and copy the script to buffer.\r\nSelect SQL results will be displayed in a saparate window.", MessageBoxType.Information, 30);
                    break;
                case "btnLaunchSQLServer":
                    _viewModel.PopupFlyMessage("Open SQL server Management Studio", MessageBoxType.Information, 30);
                    break;
                /*For the popup config*/
                case "btnEditConfig":
                    _viewModel.PopupFlyMessage("If you apply setting from the \"Developer Checklist\" you are done with the initial settings.\r\nOtherwise, you are required to verify if every default setting is correct.\r\nPlease dont delete the default settings, modify them instead.\r\nYou can add//update or delete the key (if there are multiple/duplicated keys).\"FrequentlyUseSQL\" only.\r\n", MessageBoxType.Information, 50);
                    break;               
                case "txtConfigKey":
                    _viewModel.PopupFlyMessage("Config Key values are the values used in the controls (dropdown lists) of this utility.\r\nAll keys from the original setting are used by the application.\r\nYou can Add//Delete extra record but Please do not delete all keys.\r\nAt least 1 Key from each category is required to be in the list.\r\n Note:\r\nNew key will not be used in the application", MessageBoxType.Information, 30);
                    break;
                case "txtConfigValue":
                    _viewModel.PopupFlyMessage("The values which are being used in the dropdowns or textboxes controls in the Utility application.\r\nSome are used internally example: \"powershell_iseLocation\"\r\nWarning:\r\nIf the value is not correct, the application might failed to load.\r\nYou might have to reload the original configuration.\r\n", MessageBoxType.Information, 30);
                    break;
                case "txtConfigName":
                    _viewModel.PopupFlyMessage("This is just the description to help identify what the keys are.", MessageBoxType.Information, 30);
                    break;
                case "btnDeleteConfig":
                    _viewModel.PopupFlyMessage("Delete Configuration:\r\nIf a config is wrong or no longer applicable, you can delete.\r\nPlease don't delete the last key.", MessageBoxType.Warning, 30);
                    break;               
                case "btnCloseConfig":
                    _viewModel.PopupFlyMessage("Close without save what is on the screen.", MessageBoxType.Information, 5);
                    break;
                case "btnSaveConfig":
                    _viewModel.PopupFlyMessage("Save and reload the screen.\r\n***Save rule:\r\nThe real unique identifier of the record is Key and Description.\r\nSo if one or both value are changed, then new record created, otherwise, update.", MessageBoxType.Information, 30);
                    break;
                case "TextProjectPathSelected":
                    _viewModel.PopupFlyMessage("Source Code path.\r\nNote:\r\nTo verify the path, double click on the text field.", MessageBoxType.Information, 30);
                    break;
                default:
                    //  string temp = $"case \"{btName}\":\r\n_viewModel.PopupFlyMessage(\"???\", MessageBoxType.Information, 1);\r\nbreak;\r\n";
                    //Debug.Write(temp);
                    _viewModel.PopupFlyMessage("", MessageBoxType.Information, 1);
                    break;
            }
           
        }

        private void ShowFlyoutMessage(object sender, System.Windows.Input.MouseEventArgs e)
        {
            ShowFlyoutMessage(sender, null);
        }
    }
}
﻿using System;
using WPF.PSE.AppLayer.DataObject;

namespace WPF.PSE.Utility
{
    public sealed class IntermediateEvent
    {
        private IntermediateEvent()
        {;}

        public static readonly IntermediateEvent _IntermediateEvent = new IntermediateEvent();

        public static IntermediateEvent GetIntermediateEvent => _IntermediateEvent;

        public event EventHandler<CommandChangeEventArg> CommandChange;

        public void OnCommandChangedChanged(Object sender, User job)
        {
            var commandChangedDelegate = CommandChange as EventHandler<CommandChangeEventArg>;

        }
    }
}

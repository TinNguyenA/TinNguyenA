﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Threading;
using Common.PSELibrary;
using Common.PSELibrary.CustomObjects;
using WPF.PSE.AppLayer.DataObject;
using WPF.PSE.AppLayer.Models;
using WPF.PSE.Utility.UserControls;
using WPF.PSE.ViewModelLayer;

namespace WPF.PSE.Utility
{
    public partial class MainWindow : Window
    {
        #region Constructor
        public MainWindow()
        {
            //default
            InitializeComponent();            
            // Connect to instance of the view model created by the XAML
            _viewModel = (MainWindowViewModel)this.Resources["viewModel"];

            // Get the original status message
            _originalMessage = _viewModel.StatusMessage;
            // Initialize the Message Broker Events. This allow this mainwindow to receive commands sent from the children (bubble up event)
            MessageBroker.Instance.MessageReceived += Instance_MessageReceived;                       
        }
        #endregion

        #region Private variables
        // Main window's view model class
        private MainWindowViewModel _viewModel = null;
        // Hold the main window's original status message
        private string _originalMessage = string.Empty;
        private AppCookie cookie = new AppCookie();
        #endregion

        #region Window_Loaded Event
        private async void Window_Loaded(object sender, RoutedEventArgs e)
        {
            // Call method to load resources application
            await LoadApplication();
            // Turn off informational message area
            _viewModel.ClearInfoMessages();
        }
        #endregion

        #region Instance_MessageReceived Event
        private void Instance_MessageReceived(object sender, MessageBrokerEventArgs e)
        {
            switch (e.MessageName)
            {
                case MessageBrokerMessages.FILE_COPY_ISSUE:
                    _viewModel.InfoMessageTimeout = 3000;
                    _viewModel.InfoMessageTitle = "File was busy or opening.";
                    _viewModel.CreateInfoMessageTimer();
                    _viewModel.StatusMessage = "Retry later";
                    break;
                case MessageBrokerMessages.LOGIN_SUCCESS:
                    _viewModel.InfoMessageTimeout = 3000;
                    _viewModel.InfoMessageTitle = "Your PA Account is logon successfully.";
                    _viewModel.CreateInfoMessageTimer();
                    _viewModel.StatusMessage = "Logon completed";
                    if (UserCredential != null)
                        UserCredential.IsLoggedIn = true;
                    break;
                case MessageBrokerMessages.LOGOUT:

                    _viewModel.CreateInfoMessageTimer();
                    LoginText.Header = "Login to your PA Account";
                    if (UserCredential != null)
                        UserCredential.Password = null;
                    break;
                case MessageBrokerMessages.DISPLAY_TIMEOUT_INFO_MESSAGE_TITLE:
                    _viewModel.InfoMessageTitle = e.MessagePayload.ToString();
                    _viewModel.CreateInfoMessageTimer();
                    break;

                case MessageBrokerMessages.DISPLAY_TIMEOUT_INFO_MESSAGE:   
                    _viewModel.InfoMessageTimeout = int.Parse(((MessageView)e.MessagePayload).Payload.ToString());
                    _viewModel.InfoMessage = ((MessageView)e.MessagePayload).InfoMessage;
                    _viewModel.InfoMessageTitle = ((MessageView)e.MessagePayload).InfoMessageTitle;
                    _viewModel.CreateInfoMessageTimer();
                    break;

                case MessageBrokerMessages.DISPLAY_STATUS_MESSAGE:
                    // Set new status message
                    _viewModel.StatusMessage = e.MessagePayload.ToString();                   
                    break;
                case MessageBrokerMessages.CLOSE_USER_CONTROL:
                    CloseAllUserControls();
                    break;
                case MessageBrokerMessages.CLOSE_TABPAGE_BY_NAME:
                    CloseTabPageUserControl(e.MessagePayload.ToString());
                    break;
                case MessageBrokerMessages.CLOSE_CURRENTINSTANCE:
                    this.Close();                    
                    break;
                case MessageBrokerMessages.DISPLAY_HEADER_MESSAGE:
                    this.Title = e.MessagePayload.ToString();
                    break;
                case MessageBrokerMessages.DISPLAY_ERROR_MESSAGE:
                    erMessage = e.MessagePayload.ToString();
                    Task.Factory.StartNew(PopupMessageInnewThread);
                    break;
                case MessageBrokerMessages.DISPLAY_POPUP_MESSAGE:                   
                    if (!((MessageView)e.MessagePayload).IsInfoMessageVisible)
                        _viewModel.ClearInfoMessages();
                    else{
                        _viewModel.IsInfoMessageVisible = ((MessageView)e.MessagePayload).IsInfoMessageVisible;
                        _viewModel.InfoMessage = ((MessageView)e.MessagePayload).InfoMessage;
                        _viewModel.InfoMessageTimeout = ((MessageView)e.MessagePayload).PopUpTimmer;
                        _viewModel.InfoMessageTitle = ((MessageView)e.MessagePayload).InfoMessageTitle;
                        _viewModel.CreateInfoMessageTimer();
                    }
                    break;
                case MessageBrokerMessages.LOGIN_PASS:
                    LoginText.Header = "Logout " + ((User)e.MessagePayload).UserName;                    
                    UserCredential = e.MessagePayload as User;
                    UserCredential.IsLoggedIn = true;
                    StatusMessage.Text = "Please use Start menu on top to open the Utility";
                    break;
                case MessageBrokerMessages.LOGIN_FAIL:
                    StatusMessage.Text = $"failed to login: {e.MessagePayload.ToString()}";
                    break;

                //default:    
                    //throw new NotImplementedException();
            }
        }
        private string erMessage = "";

        public static User UserCredential { get; private set; }

        private void PopupMessageInnewThread()
        {
            MessageBox.Show(erMessage, "Information", MessageBoxButton.OK);
        }

        private void CloseTabPageUserControl(string Id)
        {
            TabItem tabpageToRemove = new TabItem();
            foreach (var container in contentArea.Children)
            {
                if (container is ServerListObject)
                {
                    foreach (var subContainer in ((ServerListObject)container).contentArea.Children)
                    {
                        if (subContainer is TabPageControl)
                        {
                            foreach (TabItem tabpage in ((TabPageControl)subContainer).TabPlaceHolder.Items)
                            {
                                if (tabpage.Header.ToString() == Id)
                                {
                                    tabpageToRemove = tabpage;
                                    break;
                                }
                            }
                            if (tabpageToRemove.Header?.ToString() == Id)
                            {
                                ((TabPageControl)subContainer).TabPlaceHolder.Items.Remove(tabpageToRemove);
                                break;
                            }
                        }
                    }
                }
            }
        }
        #endregion

        #region MenuItem_Click Event
        private void MenuItem_Click(object sender, RoutedEventArgs e)
        {
            string cmd = string.Empty;
            MenuItem mnu = (MenuItem)sender;
            
            // The Tag property contains a command 
            // or the name of a user control to load
            if (mnu.Tag != null)
            {
                UncheckMenue(AllMenuItems.Items);
                cmd = mnu.Tag.ToString();

                if (cmd.Contains("."))
                {
                    //if (LoadUserControl(cmd, AppCookie.mAppCoockie))
                    if (LoadUserControl(cmd, null))
                        this.Title = mnu.Header + " Utility";
                    if (this.Title.Contains("SQL"))
                        this.Title += " (run as Administrator!!!))";
                    mnu.IsChecked = true;
                }
                else
                {
                    // Process special area require login (not used)
                    ProcessMenuCommands(cmd);
                }
            }
        }

        private void UncheckMenue(ItemCollection items)
        {
            foreach (var it in items)
            {
                foreach (var item in ((ItemsControl)it).Items)
                {
                    if (item is MenuItem)
                        ((MenuItem)item).IsChecked = false;
                }
            }
        }
        #endregion

        #region LoadUserControl Method
        private bool LoadUserControl(string controlName, IDictionary<string, string> ccList)
        {
            Type ucType = null;
            UserControl uc = null;
            if (ShouldLoadUserControl(controlName))
            {
                // Create a Type from controlName parameter
                ucType = Type.GetType(controlName);
                if (ucType == null)
                {
                    MessageBox.Show("The Control: " + controlName
                                     + " does not exist.", "Warning");
                    return false;
                }

                if (ccList != null && ccList.Count > 0)
                {
                    if (ccList["ModuleSelected"] != controlName)
                    {
                        ccList["ModuleSelected"] = controlName;
                        cookie.Save(ccList);
                    }
                    
                }
                // Close current user control in content area
                // NOTE: Optionally add current user control to a list 
                //so you can restore it when you close the newly added one
                CloseAllUserControls();

                // Load this User control
                uc = (UserControl)Activator.CreateInstance(ucType, ccList);

                if (uc != null)
                {
                    DynamicallyChangeSize(uc);
                    // Display control in content area
                    DisplayUserControl(uc);
                    return true;
                }
            }
            return false;
        }

        private void DynamicallyChangeSize(UserControl uc)
        {
            ((IPSUserControl)uc).MWidth = this.Width - 25;
            ((IPSUserControl)uc).MHeight = this.Height - 100;

            ((IPSUserControl)uc).TabWidth = this.Width - 60;
            ((IPSUserControl)uc).TabHeight = this.Height - 220;
        }
        #endregion

        #region DisplayUserControl Method
        public void DisplayUserControl(UserControl uc)
        {
            // Add new user control to content area
            contentArea.Children.Add(uc);
        }
        #endregion

        #region ProcessMenuCommands Method
        private void ProcessMenuCommands(string command)
        {
            if (UserCredential != null)
            {
                UserCredential = null;
                CloseAllUserControls();
                LoginText.Header = _viewModel.LoginMenuHeader;                
            }
            else if (command == "login")
            {
                //LoadUserControl("WPF.PSE.Utility.UserControls.LoginControl", AppCookie.mAppCoockie);
                LoadUserControl("WPF.PSE.Utility.UserControls.LoginControl", null);
            }
            this.Title = "Use Powershell module permision";
        }
        #endregion

        #region ShouldLoadUserControl Method
        /// <param name="controlName"></param>
        /// <returns>If your UC leanded before return False</returns>
        private bool ShouldLoadUserControl(string controlName)
        {
            bool ret = true;

            // Make sure you don't reload a control already loaded.
            if (contentArea.Children.Count > 0)
            {
                if (((UserControl)contentArea.Children[0]).GetType().FullName == controlName)
                {
                    ret = false;
                }
            }

            return ret;
        }
        #endregion

        #region CloseUserControl Method
        private void CloseAllUserControls()
        {
            // Remove current user control
            contentArea.Children.Clear();

            // Restore the original status message
            _viewModel.StatusMessage = _originalMessage;
        }
        #endregion

        #region LoadApplication Method
        public async Task LoadApplication()
        {
            /*@Todo later*/
            _viewModel.InfoMessage = "Loading User Profile...";
            await Dispatcher.BeginInvoke(new Action(() =>
            {
                _viewModel.LoadUserProfile();
                ///anything needs to load initially here
            }), DispatcherPriority.Background);

            _viewModel.InfoMessage = "NOTE: !!!!Always Run as Administrator!!!!";
            await Dispatcher.BeginInvoke(new Action(() =>
            {
                _viewModel.LoadProcedureCodes();
                //Load business logic here
                if (AppCookie.mAppCoockie != null && AppCookie.mAppCoockie.Count>0)
                {
                    // LoadUserControl(AppCookie.mAppCoockie["ModuleSelected"], AppCookie.mAppCoockie);
                    LoadUserControl(AppCookie.mAppCoockie["ModuleSelected"], null);
                }
                else
                {
                    //LoadUserControl("WPF.PSE.Utility.UserControls.ServerListObject", AppCookie.mAppCoockie);
                    LoadUserControl("WPF.PSE.Utility.UserControls.PSSetActiveProject", null);
                }
            }), DispatcherPriority.Background);
        }
        #endregion

        private void AdjustScreenLayout(object sender, SizeChangedEventArgs e)
        {
            if (this.WindowState == WindowState.Maximized || this.WindowState == WindowState.Minimized)
            {
                this.Height = System.Windows.Forms.Screen.PrimaryScreen.Bounds.Height - 10;
                this.Width = System.Windows.Forms.Screen.PrimaryScreen.Bounds.Width;
            }
            foreach (var container in contentArea.Children)
            {
                DynamicallyChangeSize(container as UserControl);
            }
        }
        public static string GetLocalRepo()
        {
            var _utilsData = new UtilDataContext().LoadUtilityData<CODISUtilGenericData>();
            if (_utilsData.Items.Any(x => x.Key == "Environment Variables" && x.Name == "LocalRepo"))
                return _utilsData.Items.Where(x => x.Key == "Environment Variables" && x.Name == "LocalRepo").First().Value;
            return "";
        }
    }
}
﻿namespace WPF.PSE.Utility
{
    public class CommandChangeEventArg
    {
    }
}
﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Xml.Serialization;
using WPF.PSE.Common;

namespace WPF.PSE.AppLayer.DataObject
{
    public partial class AppCookie
    {
        public static IDictionary<string, string> mAppCoockie;
        public static AppCookie _AppCookie;
        public static void SetCurrentCookies()
        {
            mAppCoockie = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
            //get from Temp
            string strFullPath = Path.Combine(Path.GetTempPath(), "Ip.Cookies");
            if (File.Exists(strFullPath))
            {
                //read()
                using (FileStream reader = new FileStream(strFullPath, FileMode.Open))
                {
                   // File.OpenRead(strFullPath)
                    AppCookie coockie = CommonFunctions.ConvertXMLToClassObject<AppCookie>(reader);
                    foreach (CookieObject cc in coockie.Items)
                    {
                        mAppCoockie.Add(cc.Name, cc.Value);
                    }
                }
                
            }
            else
            {
                //Create() and write default value
                AppCookie coockie = new AppCookie();
                coockie.Items = new CookieObject[]{ new CookieObject() { Name = "ModuleSelected", Value = Constant.XMLModule },
                                                     new CookieObject() { Name = "ModuleCommandSelectedIndex", Value = "-1" },
                                                     new CookieObject() { Name = "Created", Value = DateTime.Now.ToShortDateString() }};

                WriteObjectToFile(coockie, strFullPath);
            }
        }
        public static void WriteObjectToFile<T>(T classObject, string pathFile = "") where T : class
        {
            if (pathFile == "")
                pathFile = Path.Combine(Path.GetTempPath(), "Ip.Cookies");
            using (StreamWriter streamWriter = new StreamWriter(pathFile))
            {
                XmlSerializer serializer = new XmlSerializer(typeof(T));
                serializer.Serialize(streamWriter, classObject);
            }
        }
        public void Save(IDictionary<string, string> ccList)
        {
            if (ccList == null)
                return;
            string pathFile = Path.Combine(Path.GetTempPath(), "Ip.Cookies");

            AppCookie coockie = new AppCookie();
            CookieObject[] obj = new CookieObject[ccList.Count];
            int i = 0;
            foreach (var item in ccList)
            {
                obj[i++] = new CookieObject() { Name = item.Key, Value = item.Value};
            }
            coockie.Items = obj;
            using (StreamWriter streamWriter = new StreamWriter(pathFile))
            {
                XmlSerializer serializer = new XmlSerializer(typeof(AppCookie));
                serializer.Serialize(streamWriter, coockie);
            }
        }
    }
}

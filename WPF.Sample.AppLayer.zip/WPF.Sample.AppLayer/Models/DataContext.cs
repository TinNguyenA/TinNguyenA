﻿using System;
using System.Configuration;
using System.Data;
using System.Data.SqlTypes;
using System.IO;
using System.Linq;
using System.Windows.Forms;
using System.Xml.Schema;
using System.Xml;
using WPF.PSE.AppLayer.DataObject;
using WPF.PSE.Common;
using System.Text;
using System.Runtime.InteropServices.ComTypes;

namespace WPF.PSE.AppLayer.Models
{
    public class UtilDataContext
    {
        public object MessageBoxImage { get; private set; }

        public UtilDataContext()
        {
        }

        public Stream GetStream(string resourceFile, bool getFromCodisMVPath = false, bool ? overrideMode=false)
        {
            string[] temp = { "Data", resourceFile };
            string path = String.Join("\\", temp.ToArray());
            string path2 = Path.Combine(Environment.GetEnvironmentVariable("MV"),"UtilityData", resourceFile);
            var dirCheck = path2.TrimEnd(resourceFile.ToCharArray());
            if (!Directory.Exists(dirCheck))
                Directory.CreateDirectory(dirCheck);
            if (getFromCodisMVPath)
            {               
                if (!File.Exists(path2) || !overrideMode.HasValue || overrideMode.Value == true)
                {
                    // /backup for null overrideMode
                    if (!overrideMode.HasValue)
                        File.Copy(path2, path2 + $"_Bak{DateTime.Now.ToOADate()}", true);

                    File.Copy(path, path2, !overrideMode.HasValue || overrideMode.Value == true);
                    
                }               
            }
            else if (!File.Exists(path))
            {
                // create initial file
                CreateXMLFile(path);
                File.Copy(path, path2, !overrideMode.HasValue || overrideMode.Value == true);
            }
            else
            {
                if (!File.Exists(path2))
                {
                    File.Copy(path, path2, !overrideMode.HasValue || overrideMode.Value == true);
                }
            }
            return File.OpenRead(path2);
        }

        public void WriteDataSetToFile(DataSet dataSet, string confFile)
        {
            string[] temp = { "Data", confFile };
            string path = String.Join("\\", temp.ToArray());

            dataSet.WriteXml(Path.Combine(path));
        }
        private void CreateXMLFile(string strFileNameLoc)
        {
            DataSet DS = new DataSet();
            DS.DataSetName = "ArrayOfFileManagerData";
            DataTable dataTable1 = DS.Tables.Add("FileManagerData");
            DataColumn dataColumn1 = dataTable1.Columns.Add("HistSynID", typeof(int));
            //DataColumn dataColumn2 = dataTable1.Columns.Add("HistSource", typeof(string));
            //DataColumn dataColumn3 = dataTable1.Columns.Add("HistDest", typeof(string));
            //DataColumn dataColumn4 = dataTable1.Columns.Add("insertedDT", typeof(string));
            //DataColumn dataColumn5 = dataTable1.Columns.Add("FileType", typeof(string));
            //DataColumn dataColumn6 = dataTable1.Columns.Add("Description", typeof(string));
            //DataColumn dataColumn7 = dataTable1.Columns.Add("FileTypeExcept", typeof(string));
            DataColumn[] dataColumnArray1 = new DataColumn[] { dataColumn1 };
            dataTable1.PrimaryKey = dataColumnArray1;
            DataRow dataRow1 = dataTable1.NewRow();
            dataRow1[0] = "0";
            dataRow1[1] = "";
            dataRow1[2] = "";
            dataRow1[3] = "12/31/2021";
            dataRow1[4] = "";
            dataRow1[5] = "";
            dataRow1[6] = "";
            dataTable1.Rows.Add(dataRow1);
            DS.WriteXml(strFileNameLoc, XmlWriteMode.IgnoreSchema);
        }

        public T LoadUtilityData<T>() where T : class
        {
            T _utilsData;
            using (Stream stream = new UtilDataContext().GetStream("CODISUtilGenericData.xml", true, false))
            {
                _utilsData = CommonFunctions.ConvertXMLToClassObject<T>(stream);
            }

            if (!AllKeyArePresenting(_utilsData))
            {
                using (Stream stream = new UtilDataContext().GetStream("CODISUtilGenericData.xml", true, null))
                {
                    _utilsData = CommonFunctions.ConvertXMLToClassObject<T>(stream);
                }
                MessageBox.Show("Your default setting is automatically backed up due to new version of the Utility.\r\n To migrate your old setting, please manually copy from the CODISUtilGenericData.xml_Bak File", "Notice",
                    MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            return _utilsData;
        }
        public bool SaveUtilityData<T>(T _utilsData, string fullPath) where T : class
        {
            string xml = CommonFunctions.ConvertClassObjectToXmlString(_utilsData);
            xml = xml.Replace("encoding=\"utf-16\"", "encoding=\"utf-8\"");
            xml = xml.Replace(" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\">", ">");
            xml = xml.Replace("<ArrayOfUtilityGenericData", "<CODISUtilGenericData");
            xml = xml.Replace("<UtilityGenericData", "<UtilGenericData");
            xml = xml.Replace("</ArrayOfUtilGenericData", "</UtilityGenericData");
            xml = xml.Replace("</UtilityGenericData", "</UtilGenericData");
            xml = xml.Replace("</ArrayOfUtilityGenericData", "</CODISUtilGenericData");
            using (StreamWriter writer = new StreamWriter(fullPath))
            {
                writer.Write(xml);
            }
            return true;
        }
            private bool AllKeyArePresenting<T>(T _utilsData)
        {
            if (_utilsData is CODISUtilGenericData)
            {
                CODISUtilGenericData data = _utilsData as CODISUtilGenericData;
                return data.Items.Any(x => x.Key == "PSScriptGetLatestCompileCODIS") &&
                    data.Items.Any(x => x.Key == "PSScriptGetLatestCompileISG") &&
                    data.Items.Any(x => x.Key == "PSScriptGetLatestCompileRapid") &&
                    data.Items.Any(x => x.Key == "MSBuild_exe") &&
                    data.Items.Any(x => x.Key == "tf_exe") &&
                    data.Items.Any(x => x.Key == "powershell_iseLocation") &&
                    data.Items.Any(x => x.Key == "ISG_exeLocation") &&
                    data.Items.Any(x => x.Key == "CREPath");
            }
            return false;
        }
    }
}

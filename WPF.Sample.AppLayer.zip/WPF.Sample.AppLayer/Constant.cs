﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WPF.PSE.AppLayer
{
    public static class Constant
    {
        public static string PSModule = "WPF.PSE.Utility.UserControls.ServerListObject";
        public static string XMLModule = "WPF.PSE.Utility.UserControls.XMLValidation";
        public static int DefaultPopUpTimeout = 700; // milliseconds
    }
}

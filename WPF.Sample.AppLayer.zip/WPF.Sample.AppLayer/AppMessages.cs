﻿//
using Common.PSELibrary;

namespace WPF.PSE.AppLayer
{
  /// <summary>
  /// This class is for application-specific message broker messages
  /// </summary>
  public class AppMessages : MessageBrokerMessages
  {
  }
}

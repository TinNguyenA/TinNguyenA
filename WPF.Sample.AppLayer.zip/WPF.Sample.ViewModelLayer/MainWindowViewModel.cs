﻿using Common.PSELibrary;
using WPF.PSE.AppLayer.DataObject;

namespace WPF.PSE.ViewModelLayer
{
    public class MainWindowViewModel : ViewModelBase
    {
        #region Private Variables
        private const int SECONDS = 1000;
        private string _LoginMenuHeader = "Use Your Pa Account";

        #endregion

        #region Public Properties
        public string LoginMenuHeader
        {
            get
            {
                return _LoginMenuHeader;
            }
            set
            {
                _LoginMenuHeader = value;
                RaisePropertyChanged("LoginMenuHeader");
            }
        }
        #endregion  

        #region ClearInfoMessage Method
        public void ClearInfoMessages()
        {
            InfoMessage = string.Empty;
            InfoMessageTitle = string.Empty;
            IsInfoMessageVisible = false;
        }
        #endregion

       
        #region LoadStateCodes Method
        public void LoadUserProfile()
        {
            // load cookie
            AppCookie.SetCurrentCookies();
           
            System.Threading.Thread.Sleep(SECONDS);
        }
        #endregion

        #region Loadflash message Method
        public void LoadProcedureCodes()
        {
            // TODO: Write code to load procedure codes here if needed
            System.Threading.Thread.Sleep(SECONDS);
        }
        #endregion

        #region Loadinitial Method base on last openning
        public void LoadEmployeeTypes()
        {
            // TODO: Write code to Ensure Power shell version and privilege here
            System.Threading.Thread.Sleep(SECONDS);
        }

        #endregion
    }
}

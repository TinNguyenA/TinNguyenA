﻿using Common.PSELibrary;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WPF.PSE.AppLayer.DataObject;
using WPF.PSE.AppLayer.Models;
using WPF.PSE.Common;

namespace WPF.PSE.ViewModelLayer
{
    public class FileExploreViewModel : ViewModelBase   
    {
        public ArrayOfFileManagerDataFileManagerData[] LoadFileHistFromXML()
        {
            Stream stream = new UtilDataContext().GetStream(Environment.MachineName + ".xml");
            ArrayOfFileManagerData database = CommonFunctions.ConvertXMLToClassObject<ArrayOfFileManagerData>(stream);
            stream.Close();
            return database?.Items;
        }

        public void SaveHistToXMLFile(ArrayOfFileManagerDataFileManagerData[] data, string path)
        {
            //Stream stream = new FileStream(path + Environment.MachineName + ".xml",
            //    FileMode.Open, FileAccess.Write);
            //CommonFunctions.ConvertClassObjectToXML(stream, data);
            CommonFunctions.ConvertClassObjectToXmlString(data);
            //stream.Close();
        }

        public void SaveToFileManagerConfig(ArrayOfFileManagerDataFileManagerData newRecord, float updId)
        {            
            DataSet dataSet = new DataSet();
            Stream stream = new UtilDataContext().GetStream(Environment.MachineName + ".xml");
            dataSet.ReadXml(stream);
            stream.Close();
            DataRow[] dataRowArray1 = dataSet.Tables[0].Select(("HistSynID=\'" + updId + "\'"));
            
            if (updId==-1)
            {
                //add
                DataRow dataRow1 = dataSet.Tables[0].NewRow();
                dataRow1["HistDest"] = newRecord.HistDest;
                dataRow1["HistSource"] = newRecord.HistSource;
                dataRow1["FileTypeExcept"] = newRecord.FileTypeExcept;
                dataRow1["FileType"] = newRecord.FileType;
                dataRow1["Description"] = newRecord.Description;
                dataRow1["HistSynID"] = newRecord.HistSynID;
                dataRow1["insertedDT"] = newRecord.insertedDT;
                dataSet.Tables["FileManagerData"].Rows.Add(dataRow1);
                new UtilDataContext().WriteDataSetToFile(dataSet, Environment.MachineName + ".xml");

            }
            else
            {
                dataRowArray1[0]["HistDest"] = newRecord.HistDest;
                dataRowArray1[0]["HistSource"] = newRecord.HistSource;
                dataRowArray1[0]["FileTypeExcept"] = newRecord.FileTypeExcept;
                dataRowArray1[0]["FileType"] = newRecord.FileType;
                dataRowArray1[0]["Description"] = newRecord.Description;
                new UtilDataContext().WriteDataSetToFile(dataSet, Environment.MachineName + ".xml");
            }
        }
    }
}

﻿using Common.PSELibrary;
using System;
using System.Diagnostics;
using System.IO;
using System.Reflection;
using WPF.PSE.AppLayer.DataObject;

namespace WPF.PSE.ViewModelLayer
{
    public class LoginViewModel : ViewModelBase
    {
        public LoginViewModel() : base()
        {
            DisplayStatusMessage("Login to Application");
            UserEntity = new User
            {
                UserName = "Pa-" + Environment.UserName.ToUpper().TrimStart("PA-".ToCharArray()),
                DomainName = Environment.UserDomainName
            };
        }
        private User _Entity;
        public User UserEntity
        {
            get
            {
                return _Entity;
            }
            set
            {
                _Entity = value;
                RaisePropertyChanged("Entity");
            }
        }

        public bool Validate()
        {
            UserEntity.IsLoggedIn = false;

            ValidationMessages.Clear();
            if (string.IsNullOrEmpty(UserEntity.UserName))
            {
                AddValidationMessage("UserName", "User Name must be Filled and begin with Pa-");
            }

            if (string.IsNullOrEmpty(UserEntity.Password))
            {
                AddValidationMessage("Password", "Password must be Filled");
            }

            return (ValidationMessages.Count == 0);
        }

        /// <summary>
        /// this validate user against database only (not used yet)
        /// </summary>
        /// <returns></returns>
        public bool Login()
        {
            bool ret = false;
            if (Validate())
            {
                if (ValidateCredentials())
                {
                    UserEntity.IsLoggedIn = true;
                }
                MessageBroker.Instance.SendMessage(MessageBrokerMessages.LOGIN_SUCCESS, UserEntity);
                //Close the User Control

                Close(false);
                ret = true;
            }

            return ret;
        }

        public void LoginAsAdmin(User payloadPass)
        {                       
            MessageBroker.Instance.SendMessage(MessageBrokerMessages.LOGIN_PASS, payloadPass);
            Close(false);
        }

        /// <summary>
        /// Redirect to itselfve with the new credential
        /// </summary>
        /// <returns>false if not success otherwise true</returns>
        public bool LoginValidate
        {
            get
            {
                var proc = new Process();
                try
                {
                    string file = Assembly.GetEntryAssembly().Location;
                    var sspw = new System.Security.SecureString();
                    foreach (var c in UserEntity.Password) sspw.AppendChar(c);
                    proc.StartInfo.WorkingDirectory = Path.GetDirectoryName(file);
                    proc.StartInfo.FileName = Path.GetFileName(file);
                    proc.StartInfo.Arguments = "True";
                    proc.StartInfo.Domain = UserEntity.DomainName;
                    proc.StartInfo.UserName = UserEntity.UserName;
                    proc.StartInfo.Password = sspw;
                    proc.StartInfo.LoadUserProfile = true;
                    proc.StartInfo.UseShellExecute = false;
                    proc.StartInfo.CreateNoWindow = true;
                    proc.Start();
                }
                catch (Exception ex)
                {
                    string message = ex.Message;
                    MessageBroker.Instance.SendMessage(MessageBrokerMessages.LOGIN_FAIL, message + UserEntity.Password);
                    return false;
                }
                proc.Kill();
                proc?.Dispose();
                MessageBroker.Instance.SendMessage(MessageBrokerMessages.LOGIN_SUCCESS);
                return true;
            }
        }

        private bool ValidateCredentials()
        {
            return true;
        }

        public override void Close(bool wasCancelled = true)
        {
            if (wasCancelled)
            {
                MessageBroker.Instance.SendMessage(
                    MessageBrokerMessages.DISPLAY_TIMEOUT_INFO_MESSAGE_TITLE,
                    " User was logout");
            }
            base.Close(wasCancelled);
        }
    }
}

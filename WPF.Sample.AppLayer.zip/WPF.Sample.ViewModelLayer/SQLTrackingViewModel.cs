﻿using Common.PSELibrary;
using Common.PSELibrary.CustomObjects;
using System.IO;
using System.Linq;
using WPF.PSE.AppLayer.DataObject;
using WPF.PSE.AppLayer.Models;
using WPF.PSE.Common;

namespace WPF.PSE.ViewModelLayer
{
    public class SQLTrackingViewModel : ViewModelBase
    {
        private CODISUtilGenericData _UtilData;
        public CODISUtilGenericData UtilData
        {
            get
            {
                if(_UtilData == null)   
                 _UtilData = new UtilDataContext().LoadUtilityData<CODISUtilGenericData>();
                return _UtilData;
            }
        }
        public DatabasesDatabase[] LoadDatabaseFromXML()
        {
            Stream stream = new UtilDataContext().GetStream("Database.xml");
            Databases database = CommonFunctions.ConvertXMLToClassObject<Databases>(stream);
            stream.Close();
            return database?.Items;
        }

        public void PopupFlyMessage(string message, MessageBoxType information, string imageFileName, int timmer = 8)
        {
        }
        public void PopupFlyMessage(string message, MessageBoxType information, int timmer=8)
        {
            if (UtilData.Items.Any(x => x.Key == "TrainingMode" && x.Value != "On"))
                return;
            if (timmer == 0)
                timmer = 1;
            MessageView msg = new MessageView()
            {
                InfoMessage = message,
                PopUpTimmer = timmer * 1000
            };
            
            switch (information)
            {
                case MessageBoxType.Exclamation:
                    msg = new MessageView()
                    {
                        InfoMessage = message,
                        InfoMessageTitle = "Wondering:",
                        IsInfoMessageVisible = timmer > 1,
                        PopUpTimmer = timmer * 1000
                    };
                    
                    break;
                case MessageBoxType.Error:
                    msg = new MessageView()
                    {
                        InfoMessage = message,
                        InfoMessageTitle = "OOPs:",
                        IsInfoMessageVisible = timmer > 1,
                        PopUpTimmer = timmer * 1000
                    }; 
                    break;
                default:
                    msg = new MessageView()
                    {
                        InfoMessage = message,
                        InfoMessageTitle = "Information",
                        IsInfoMessageVisible = timmer > 1,
                        PopUpTimmer = timmer * 1000
                    }; 
                    break;
            }
            DisplayPopUpMessage(msg);
        }

    }
}

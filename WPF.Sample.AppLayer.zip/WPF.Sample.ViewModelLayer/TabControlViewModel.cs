﻿using Common.PSELibrary;
using System;
using WPF.PSE.AppLayer;


namespace WPF.PSE.ViewModelLayer
{
    public class TabControlViewModel : ViewModelBase
    {
        public TabControlViewModel() : base()
        {
            DisplayStatusMessage("Login to Application");

        }
        public override void Close(bool wasCancelled = true)
        {
            if (wasCancelled)
            {
                MessageBroker.Instance.SendMessage(
                    MessageBrokerMessages.DISPLAY_TIMEOUT_INFO_MESSAGE_TITLE,
                    " User was logout");
            }
            base.Close(wasCancelled);
        }
        private bool ValidateCredentials()
        {
            // Let the AD do itself
            return true;
        }

        public void SetTitle(string title = "Localhost")
        {
            MessageBroker.Instance.SendMessage(
                   MessageBrokerMessages.DISPLAY_HEADER_MESSAGE, title);
        }
        public void SetFocus(string tabTemplate)
        {
            MessageBroker.Instance.SendMessage(
                  MessageBrokerMessages.FOCUS_ON_ME, tabTemplate);
        }

    }
}

﻿using System;
using System.Collections;
using System.IO;
using Common.PSELibrary;
using Common.PSELibrary.CustomObjects;
using WPF.PSE.AppLayer.DataObject;
using WPF.PSE.AppLayer.Models;
using WPF.PSE.Common;

namespace WPF.PSE.ViewModelLayer
{
    public class ServerListObjectViewModel : ViewModelBase
    {
        
        public TestEnvInfo[] LoadServerFromXML(string text)
        {
            favorites servers = CommonFunctions.ConvertXMLToClassObject<favorites>(text);
            return servers?.Items;
        }

        public ComputersComputer[] LoadServerFromXML()
        {
            Stream stream = new UtilDataContext().GetStream("Computer.xml");
            Computers servers = CommonFunctions.ConvertXMLToClassObject<Computers>(stream);
            stream.Close();
            return servers?.Items;
        }

        public IEnumerable LoadEventLogInfo()
        {
            Stream stream = new UtilDataContext().GetStream("LogInfo.xml");
            EventLogInfo logNames = CommonFunctions.ConvertXMLToClassObject<EventLogInfo>(stream);
            stream.Close();
            return logNames?.Items;
        }
        public void CloseTabByName(string id)
        {
            MessageBroker.Instance.SendMessage(
                   MessageBrokerMessages.CLOSE_TABPAGE_BY_NAME,
                   id);
        }

        public void CreateInfoMessageTimer(string message, string title, int delayTime)
        {
            var obj = new MessageView();
            obj.Payload= delayTime.ToString();
            obj.InfoMessageTitle = title;
            obj.InfoMessage = message;
            MessageBroker.Instance.SendMessage(
                  MessageBrokerMessages.DISPLAY_TIMEOUT_INFO_MESSAGE, obj);
        }

      
    }
}

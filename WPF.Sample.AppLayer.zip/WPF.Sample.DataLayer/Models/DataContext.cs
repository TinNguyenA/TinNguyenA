﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WPF.PSE.DataLayer.Models
{
    public class DataContext
    {
        public DataContext()
        {
        }
        
        public Stream GetStream(string resourceFile)
        {
            string[] temp = { "Data", "Configuration", resourceFile };
            string path = String.Join("\\", temp.ToArray());
            if (!File.Exists(path))
                throw new Exception($"File {path} does not exist");
                
            return File.OpenRead(path);
        }
    }
}

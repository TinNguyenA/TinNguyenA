﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Common.PSELibrary.CustomObjects
{
    public class MessageView
    {
        private int _PopUpTimmer =1;
        public string InfoMessage { get; set; }
        public string InfoMessageTitle { get; set; }
        public bool IsInfoMessageVisible { get; set; }
        public object Payload { get; set; }
        public int PopUpTimmer { get { return _PopUpTimmer; } set { _PopUpTimmer = value; } }
    }
}

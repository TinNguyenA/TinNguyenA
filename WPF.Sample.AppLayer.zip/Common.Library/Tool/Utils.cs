﻿using Microsoft.TeamFoundation.Client;
using Microsoft.TeamFoundation.VersionControl.Client;
using System;
using System.Collections.ObjectModel;
using System.Collections.Specialized;
using System.Diagnostics;
using System.IO;
using System.Management.Automation;
using System.Management.Automation.Runspaces;
using System.Security;
using System.Security.Principal;
using System.ServiceProcess;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Windows;
using System.Windows.Forms;

namespace Common.PSELibrary.Tool
{
    public static class Utils
    {
        private static string _StrPSErrMessage;
        private static PowerShell _ps;
        public static int RemoveChars(string input, string tobeReplacedBy = "")
        {
            var rx = new Regex(@"[\p{L}\p{Zs}+]");
            var result = rx.Replace(input, tobeReplacedBy);
            if (result.Length > 0)
                return int.Parse(result);
            return 0;
        }
        private static void AddToErrorMessage(string error)
        {
            if (string.IsNullOrWhiteSpace(error))
                return;
            _StrPSErrMessage = _StrPSErrMessage + error + "\r\n";
        }
        private static void Error_DataAdded(object sender, DataAddedEventArgs e)
        {
            AddToErrorMessage(((PSDataCollection<ErrorRecord>)sender)[e.Index].ToString());
        }
        public static string RunSQL(string sql, string scriptPath,
                                    Action<Collection<PSObject>> process_GridDataAdded,
                                    bool displayOutput = true)
        {
            using (_ps = PowerShell.Create())
            {
                _StrPSErrMessage = "";
                string path = Path.Combine(Environment.CurrentDirectory, "PsScriptLib", @"ExecuteSQL.ps1");
                if (!File.Exists(path))
                {
                    throw new Exception($"{path} does not exists.");
                }
                //PS Script file has to be runing no error. No error handle in this code.
                string scriptFile = File.ReadAllText(path).Replace("$host.ui.", "#");
                _ps.Commands.Clear();
                //ps.Streams.Verbose.DataAdded += new EventHandler<DataAddedEventArgs>(GetStatusAdded);             
                _ps.Streams.Error.DataAdded += new EventHandler<DataAddedEventArgs>(Error_DataAdded);
                _ps.AddScript(scriptFile);

                _ps.AddParameter("ServerInstance", Environment.MachineName);
                _ps.AddParameter("sql", sql);
                _ps.AddParameter("LocalRepo", scriptPath);
                if (displayOutput)
                    _ps.AddParameter("Command", "short cut");
                if(process_GridDataAdded != null)
                {
                    PSDataCollection<PSObject> results = new PSDataCollection<PSObject>();
                    Collection<PSObject> xresults = _ps.Invoke();
                    process_GridDataAdded(xresults);
                    return _StrPSErrMessage;
                }
                Collection<PSObject> collection = _ps.Invoke();
            }
            return _StrPSErrMessage;
        }

        private static void GetStatusAdded(object sender, DataAddedEventArgs e)
        {
            var debug = ((PSDataCollection<VerboseRecord>)sender)[e.Index].ToString();
        }
        private static void AsyncInvoke(IAsyncResult ar)
        {
            StringBuilder sb = new StringBuilder("\r\n");
            try
            {
                foreach (var error in _ps.Streams.Debug)
                {
                    if (string.IsNullOrEmpty(error.Message))
                        continue;
                    sb.AppendLine($"Debug: {error.Message}\r\n");
                    Debug.WriteLine("=>" + error.Message);
                }
                foreach (var error in _ps.Streams.Information)
                {
                    if (string.IsNullOrEmpty(error.MessageData.ToString()))
                        continue;
                    sb.AppendLine($"Information: {error.MessageData.ToString()}\r\n");
                    Debug.WriteLine("=>" + error.MessageData.ToString());
                }
                foreach (var error in _ps.Streams.Verbose)
                {
                    if (string.IsNullOrEmpty(error.Message))
                        continue;
                    sb.AppendLine($"Verbose: {error.Message}\r\n");
                }
                foreach (var error in _ps.Streams.Progress)
                {
                    sb.AppendLine($"Progress: {error.CurrentOperation} \r\n");
                }
                foreach (var error in _ps.Streams.Warning)
                {
                    if (string.IsNullOrEmpty(error.Message))
                        continue;
                    sb.AppendLine($"Warning: {error.Message} \r\n");
                }
                AddToErrorMessage(sb.ToString());
                _ps.EndInvoke(ar);
            }
            catch (Exception ex)
            {
                AddToErrorMessage("SQL Time out:" + ex.Message);
            }
        }

        public static string RunPSFile(string pathFileName, NameValueCollection param)
        {
            using (_ps = PowerShell.Create())
            {
                FileInfo fileInfo = new FileInfo(pathFileName);
                _StrPSErrMessage = "";
                if (!File.Exists(pathFileName))
                {
                    throw new Exception($"{pathFileName} does not exists.");
                }
                string scriptFile = File.ReadAllText(pathFileName).Replace("$host.ui.", "#").Replace("# MAIN", $"Set-Location '{fileInfo.Directory}' \r\n $PSScriptRoot = '{fileInfo.DirectoryName}'");
                var fileName = Path.GetFileName(pathFileName);
                _ps.Commands.Clear();
                _ps.AddScript(scriptFile);
                _ps.Streams.Error.DataAdded += new EventHandler<DataAddedEventArgs>(Error_DataAdded);
                foreach (var item in param)
                {
                    _ps.AddParameter(item.ToString(), param[item.ToString()]);
                }
                _ps.Invoke();
                return _StrPSErrMessage;
            }
        }
        public static string RunPSFile_Pa(string pathFileName, NameValueCollection param)
        {
            using (_ps = PowerShell.Create())
            {
                _ps.Runspace = CreatePsRunSpace();
                FileInfo fileInfo = new FileInfo(pathFileName);
                _StrPSErrMessage = "";
                if (!File.Exists(pathFileName))
                {
                    throw new Exception($"{pathFileName} does not exists.");
                }
                string scriptFile = File.ReadAllText(pathFileName).Replace("$host.ui.", "#").Replace("# MAIN", $"Set-Location '{fileInfo.Directory}' \r\n $PSScriptRoot = '{fileInfo.DirectoryName}'");
                var fileName = Path.GetFileName(pathFileName);
                _ps.Commands.Clear();
                _ps.AddScript(scriptFile);
                _ps.Streams.Error.DataAdded += new EventHandler<DataAddedEventArgs>(Error_DataAdded);
                foreach (var item in param)
                {
                    _ps.AddParameter(item.ToString(), param[item.ToString()]);
                }
                _ps.Invoke();
                return _StrPSErrMessage;
            }
        }

        public static Runspace CreatePsRunSpace(string password = "C0dis@ecs", string userName = "gdissqlserver", string domain = "CODIS​​DMSS", string computerName = ".")
        //(string password= "C0dis@ecs", string userName= "gdissqlserver", string domain= "CODIS​​DMSS", string computerName=".")
        {
            string shellUri = "http://schemas.microsoft.com/powershell/Microsoft.PowerShell";
            SecureString securePass = new SecureString();
            //foreach (char c in Resource.ImpersonatedKey)
            foreach (char c in password)
            {
                securePass.AppendChar(c);
            }
            PSCredential credential = new PSCredential(string.Concat(domain, "\\", userName),
                                                       securePass);
            WSManConnectionInfo connectionInfo = new WSManConnectionInfo(false,
                computerName, 5985, "/wsman", shellUri, credential);
            connectionInfo.OperationTimeout = 4 * 60 * 1000; // 4 minutes.
            connectionInfo.OpenTimeout = 1 * 60 * 1000; // 1 minute.

            Runspace runspace = RunspaceFactory.CreateRunspace(connectionInfo);

            runspace.Open();
            return runspace;
        }

        public static string RunPSSript(string script)
        {
            using (_ps = PowerShell.Create())
            {
                _StrPSErrMessage = "";
                //_ps.Commands.Clear();
                _ps.AddScript(script);
                _ps.Streams.Error.DataAdded += new EventHandler<DataAddedEventArgs>(Error_DataAdded);
                _ps.Invoke();
                return _StrPSErrMessage;
            }
        }

        public static string RunPSFile_Manually(string path, NameValueCollection param)
        {
            try
            {
                WindowsIdentity identity = WindowsIdentity.GetCurrent();
                WindowsPrincipal principal = new WindowsPrincipal(identity);
                bool isAdmin = principal.IsInRole(WindowsBuiltInRole.Administrator);
                if (isAdmin)
                {
                    ProcessStartInfo info = new ProcessStartInfo("C:\\WINDOWS\\system32\\WindowsPowerShell\\v1.0\\powershell_ise.exe", path);
                    info.UseShellExecute = false;
                    info.Verb = "runas";
                    Process.Start(info);
                }
                else
                    Process.Start(path);
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            return "";
        }

        public static void CloseApp(string name)
        {
            try
            {
                var processes = Process.GetProcessesByName(name);

                foreach (var process in processes)
                {
                    process.Kill();
                }
                Thread.Sleep(2);
            }
            catch (Exception ex)
            {
                System.Windows.MessageBox.Show(ex.Message + $" .Please manually close {name}.", "Close AWB Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            finally
            {

            }
        }
        public static bool StartServices(string serviceName)
        {
            try
            {
                var service = new ServiceController(serviceName);
                if (service == null)
                {
                    System.Windows.MessageBox.Show($"Unable to start '{serviceName}' service.\r\nNo Binary found.\r\nPlease compile the project now.");
                    return false;
                }
                switch (service.Status)
                {
                    case ServiceControllerStatus.Running:
                        break;
                    case ServiceControllerStatus.StartPending:
                    case ServiceControllerStatus.Paused:
                        try
                        {
                            service.WaitForStatus(ServiceControllerStatus.Running, TimeSpan.FromSeconds(30));
                        }
                        catch
                        {
                            System.Windows.MessageBox.Show($"Failed to start service.\r\nVerify in VS to ensure there is no code conflicting.\r\nYou might need to recompile with the right code.","Error", MessageBoxButton.OK, MessageBoxImage.Error);
                            return false;
                        }
                        break;
                    case ServiceControllerStatus.StopPending:
                        service.WaitForStatus(ServiceControllerStatus.Stopped, TimeSpan.FromSeconds(20));
                        service.Start();
                        break;
                    default:
                        service.Start();
                        service.WaitForStatus(ServiceControllerStatus.Running, TimeSpan.FromSeconds(20));
                        break;
                }
            }
            catch (Exception ex)
            {
                System.Windows.MessageBox.Show($"Failed to start service.\r\nVerify in VS to ensure there is no code conflicting.\r\nYou might need to recompile with the right code.", "Service start/stop Error", MessageBoxButton.OK, MessageBoxImage.Error);
                return false;
            }
            finally
            {
            }
            return true;
        }
        public static int StopServices(string serviceName)
        {
            try
            {
                var service = new ServiceController(serviceName);
                if (service == null)
                {
                    return 0;
                }
                switch (service.Status)
                {
                    case ServiceControllerStatus.Stopped:
                        break;
                    case ServiceControllerStatus.StopPending:
                    case ServiceControllerStatus.Paused:
                        try
                        {
                            service.WaitForStatus(ServiceControllerStatus.Stopped, TimeSpan.FromSeconds(20));
                        }
                        catch
                        {
                            System.Windows.Forms.MessageBox.Show($"Unable to Stop '{serviceName}' service.");
                            return 0;
                        }
                        break;
                    case ServiceControllerStatus.Running:
                    case ServiceControllerStatus.StartPending:
                        service.WaitForStatus(ServiceControllerStatus.Running, TimeSpan.FromSeconds(20));
                        service.Stop();
                        service.WaitForStatus(ServiceControllerStatus.Stopped, TimeSpan.FromSeconds(20));
                        break;
                    default:
                        service.Stop();
                        service.WaitForStatus(ServiceControllerStatus.Stopped, TimeSpan.FromSeconds(20));
                        break;
                }
                return 2;
            }
            catch (Exception ex)
            {
                System.Windows.MessageBox.Show(ex.Message, "Service Stop Error", MessageBoxButton.OK, MessageBoxImage.Error);
                return -1;
            }
            finally
            {
            }
        }
        public static void CheckOutFromTFS(string fileName)
        {
            var workspaceInfo = Workstation.Current.GetLocalWorkspaceInfo(fileName);
            if (workspaceInfo == null)
                return;

            var server = new TfsTeamProjectCollection(workspaceInfo.ServerUri);
            var workspace = workspaceInfo.GetWorkspace(server);
            workspace.PendEdit(fileName);
        }
        public static void UndoCheckOutFromTFS(string fileName, bool isWidcard = false)
        {
            RecursionType tp = isWidcard ? RecursionType.Full : RecursionType.None;
            var workspaceInfo = Workstation.Current.GetLocalWorkspaceInfo(fileName);
            if (workspaceInfo == null)
                return;
            var server = new TfsTeamProjectCollection(workspaceInfo.ServerUri);
            var workspace = workspaceInfo.GetWorkspace(server);
            workspace.Undo(fileName, tp);
        }
    }
}

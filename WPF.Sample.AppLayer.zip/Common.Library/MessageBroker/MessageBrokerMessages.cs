﻿namespace Common.PSELibrary
{
    /// <summary>
    /// This class is responsible for receiving and sending messages to classes registered to receive those messages
    /// </summary>
    public class MessageBrokerMessages
    {
        public const string DISPLAY_STATUS_MESSAGE = "DisplayStatusMessage";

        public const string DISPLAY_TIMEOUT_INFO_MESSAGE = "DisplayTimeoutInfoMessage";
        public const string DISPLAY_TIMEOUT_INFO_MESSAGE_TITLE = "DisplayTimeoutInfoMessageTitle";

        public const string CLOSE_USER_CONTROL = "CloseUserControl";
        public const string CLOSE_CURRENTINSTANCE = "CloseThisSession";
        public const string OPEN_USER_CONTROL = "OpenUserControl";

        public const string LOGIN_SUCCESS = "LoginSuccess";
        public const string LOGIN_FAIL = "LoginFail";
        public const string LOGOUT = "Logout";
        public const string LOGIN_PASS = "paPass";
        public const string FOCUS_ON_ME = "Set Focus on the control";
        public const string CLOSE_TABPAGE_BY_NAME = "CloseTabPage";
        public const string DISPLAY_HEADER_MESSAGE = "HeaderTabPage";

        public const string DISPLAY_ERROR_MESSAGE = "ErrorTabPage";
        public const string DISPLAY_POPUP_MESSAGE = "MessageInfo";
        public const string FILE_COPY_ISSUE = "FILE_COPY_ISSUE";

    }
}
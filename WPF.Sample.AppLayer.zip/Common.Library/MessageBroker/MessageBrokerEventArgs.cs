﻿using System;

namespace Common.PSELibrary
{
  /// <summary>
  /// Event args for passing data when raising event in MessageBroker
  /// </summary>
  public class MessageBrokerEventArgs : EventArgs
  {
    #region Constructors
    /// <summary>
    /// Constructor for MessageBrokerEventArgs class
    /// </summary>
    public MessageBrokerEventArgs() : base()
    {
    }

    /// <summary>
    /// Constructor for MessageBrokerEventArgs class
    /// </summary>
    /// <param name="messageName">A Message Name</param>
    /// <param name="payload">The Payload for the Message</param>
    public MessageBrokerEventArgs(string messageName, object payload, int timer) : base()
    {
      MessageName = messageName;
      MessagePayload = payload;
      PopUpTimmer = timer;
    }
    #endregion

    #region Public Properties
    /// <summary>
    /// Get/Set a Unique Message Name
    /// </summary>
    public string MessageName { get; set; }
        /// <summary>
        /// Get/Set the payload for the message
        /// </summary>
        public object MessagePayload { get; set; }

        public int PopUpTimmer { get; set; }
        #endregion
    }
}

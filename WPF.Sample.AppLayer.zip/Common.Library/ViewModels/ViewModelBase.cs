﻿using System;
using System.Collections.ObjectModel;
using System.Management.Automation;
using System.Management.Automation.Runspaces;
using System.Security;
using System.Timers;
using Common.PSELibrary;
using WPF.PSE.AppLayer;

namespace Common.PSELibrary
{
    public class ViewModelBase : CommonBase
    {
        #region Private Variables
        private ObservableCollection<ValidationMessage> _ValidationMessages = new ObservableCollection<ValidationMessage>();
        private bool _IsValidationVisible = false;
        private string _StatusMessage;

        private bool _IsInfoMessageVisible = true;
        private string _InfoMessage;

        private Timer _InfoMessageTimer = null;
        private int _InfoMessageTimeout;
        private string _InfoMessageTitle = string.Empty;
        #endregion

        #region Public Properties
        public ObservableCollection<ValidationMessage> ValidationMessages
        {
            get { return _ValidationMessages; }
            set
            {
                _ValidationMessages = value;
                RaisePropertyChanged("ValidationMessages");
            }
        }

        public bool IsValidationVisible
        {
            get { return _IsValidationVisible; }
            set
            {
                _IsValidationVisible = value;
                RaisePropertyChanged("IsValidationVisible");
            }
        }

        public string StatusMessage
        {
            get
            {
                return _StatusMessage;
            }
            set
            {
                _StatusMessage = value;
                RaisePropertyChanged("StatusMessage");
            }
        }

        public bool IsInfoMessageVisible
        {
            get
            {
                return _IsInfoMessageVisible;
            }
            set
            {
                _IsInfoMessageVisible = value;
                RaisePropertyChanged("IsInfoMessageVisible");
            }
        }

        public string InfoMessage
        {
            get
            {
                return _InfoMessage;
            }
            set
            {
                _InfoMessage = value;
                RaisePropertyChanged("InfoMessage");
            }
        }

        public string InfoMessageTitle
        {
            get
            {
                return _InfoMessageTitle;
            }
            set
            {
                _InfoMessageTitle = value;
                RaisePropertyChanged("InfoMessageTitle");
            }
        }

        public int InfoMessageTimeout
        {
            get
            {
                return _InfoMessageTimeout;
            }
            set
            {
                _InfoMessageTimeout = value;
                RaisePropertyChanged("InfoMessageTimeout");
            }
        }

        #endregion

        #region AddBusinessRuleMessage Method
        public virtual void AddValidationMessage(string propertyName, string msg)
        {
            _ValidationMessages.Add(new ValidationMessage { Message = msg, PropertyName = propertyName });
            IsValidationVisible = true;
        }
        #endregion

        #region Clear Method
        public virtual void Clear()
        {
            ValidationMessages.Clear();
            IsValidationVisible = false;
        }
        #endregion

        #region Message Timer Methods
        public virtual void CreateInfoMessageTimer()
        {
            if (_InfoMessageTimer == null)
            {
                // Create informational message timer
                _InfoMessageTimer = new Timer(InfoMessageTimeout);
                // Connect to an Elapsed event
                _InfoMessageTimer.Elapsed += _MessageTimer_Elapsed;
            }
            _InfoMessageTimer.AutoReset = false;
            _InfoMessageTimer.Enabled = true;
            IsInfoMessageVisible = true;
        }


        public void _MessageTimer_Elapsed(object sender, ElapsedEventArgs e)
        {
            IsInfoMessageVisible = false;
            InfoMessageTimeout = 5000;
        }
        #endregion

        #region DisplayStatusMessage Method
        /// <summary>
        /// display bottom text
        /// </summary>
        /// <param name="msg"></param>
        public virtual void DisplayStatusMessage(string msg = "")
        {
            MessageBroker.Instance.SendMessage(MessageBrokerMessages.DISPLAY_STATUS_MESSAGE, msg);
        }
        /// <summary>
        ///  create the modal message
        /// </summary>
        /// <param name="MessageView">CustomObjects.MessageView</param>
        public virtual void DisplayPopUpMessage(CustomObjects.MessageView msg)
        {
            MessageBroker.Instance.SendMessage(MessageBrokerMessages.DISPLAY_POPUP_MESSAGE, msg);
        }
        /// <summary>
        ///  create the popup message
        /// </summary>
        /// <param name="msg"></param>
        public virtual void DisplayErrorMessage(string msg = "")
        {
            MessageBroker.Instance.SendMessage(MessageBrokerMessages.DISPLAY_ERROR_MESSAGE, msg);
        }
        #endregion

        #region PublishException Method
        public void PublishException(Exception ex)
        {
            // Publish Exception
            ExceptionManager.Instance.Publish(ex);
        }
        #endregion

        #region Close Method
        public virtual void Close(bool wasCancelled = true)
        {
            MessageBroker.Instance.SendMessage(MessageBrokerMessages.CLOSE_USER_CONTROL, wasCancelled);
        }
        public virtual void CloseParent(bool wasCancelled = true)
        {
            MessageBroker.Instance.SendMessage(MessageBrokerMessages.CLOSE_CURRENTINSTANCE, wasCancelled);
        }
        #endregion

        public Runspace CreatePsRunSpace(ref Runspace runspace, string password, string userName, string domain, string computerName)
        {
            string shellUri = "http://schemas.microsoft.com/powershell/Microsoft.PowerShell";
            SecureString securePass = new SecureString();
            //foreach (char c in Resource.ImpersonatedKey)
            foreach (char c in password)
            {
                securePass.AppendChar(c);
            }
            //PSCredential credential = new PSCredential(Resource.ImpersonatedName, securePass);
            PSCredential credential = new PSCredential(string.Concat(domain, "\\", userName),
                                                       securePass);
            WSManConnectionInfo connectionInfo = new WSManConnectionInfo(false,
                computerName, 5985, "/wsman", shellUri, credential);
            connectionInfo.OperationTimeout = 4 * 60 * 1000; // 4 minutes.
            connectionInfo.OpenTimeout = 1 * 60 * 1000; // 1 minute.

            runspace = RunspaceFactory.CreateRunspace(connectionInfo);

            runspace.Open();
            return runspace;
        }

        #region Dispose Method
        public virtual void Dispose()
        {
        }
        #endregion
    }
    public enum MessageBoxType
    {
        None = 0,       
        Question = 0x20,        
        Exclamation = 48,
        Stop = 0x10,
        Error = 0x10,
        Warning = 48,
        Information = 0x40,
        Image= 0x80
    }
}
